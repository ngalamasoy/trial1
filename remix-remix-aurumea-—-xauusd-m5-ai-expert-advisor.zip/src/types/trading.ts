export interface Candle {
  time: number; // Unix timestamp in seconds (aligned to 5m boundary)
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface IndicatorSnapshot {
  ema9: number | null;
  ema21: number | null;
  ema50: number | null;
  ema200: number | null;
  rsi14: number | null;
  macd: {
    line: number | null;
    signal: number | null;
    histogram: number | null;
  };
  atr14: number | null;
  bollinger: {
    upper: number | null;
    middle: number | null;
    lower: number | null;
  };
  swingHigh: number;
  swingLow: number;
}

export interface MarketQuote {
  symbol: string;
  timeframe: 'M5';
  bid: number;
  ask: number;
  mid: number;
  spread: number;
  change24h: number;
  changePercent24h: number;
  high24h: number;
  low24h: number;
  source: string;
  marketStatus: 'LIVE' | 'DELAYED';
  updatedAt: number;
  candleCloseInSec: number;
}

export interface MarketSnapshot {
  quote: MarketQuote;
  candles: Candle[];
  indicators: IndicatorSnapshot;
  ema9Series: Array<{ time: number; value: number }>;
  ema21Series: Array<{ time: number; value: number }>;
  ema50Series: Array<{ time: number; value: number }>;
  bbUpperSeries: Array<{ time: number; value: number }>;
  bbLowerSeries: Array<{ time: number; value: number }>;
}

export type TradeSignalType = 'BUY' | 'SELL' | 'HOLD';
export type MarketBias = 'BULLISH' | 'BEARISH' | 'RANGING';

export interface EaAnalysisResult {
  id: string;
  timestamp: number;
  candleTime: number;
  priceAtAnalysis: number;
  signal: TradeSignalType;
  confidence: number;
  marketBias: MarketBias;
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  riskRewardRatio: string;
  setupPattern: string;
  summary: string;
  keyFactors: string[];
  invalidatedIf: string;
  model: string;
  latencyMs: number;
  usedChartVision: boolean;
  judgeVerdict?: string;
  indicatorWeighting?: string;
  authorityMode?: 'AI_JUDGE_100' | 'CONFIDENCE_FILTER';
}

export interface OpenPosition {
  id: string;
  side: 'BUY' | 'SELL';
  lots: number;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  openedAt: number;
  source: 'AI_AUTO' | 'AI_MANUAL' | 'MARKET_MANUAL' | 'MT5_LIVE';
  confidence?: number;
  setupPattern?: string;
  highestFavorablePrice: number;
  trailingActivated: boolean;
  mt5Ticket?: number;
}

export interface ClosedTrade {
  id: string;
  side: 'BUY' | 'SELL';
  lots: number;
  entryPrice: number;
  closePrice: number;
  stopLoss: number;
  takeProfit: number;
  openedAt: number;
  closedAt: number;
  pnlUsd: number;
  points: number;
  closeReason: 'TP Hit' | 'SL Hit' | 'Trailing SL' | 'Manual Close' | 'MT5 Sync';
  source: 'AI_AUTO' | 'AI_MANUAL' | 'MARKET_MANUAL' | 'MT5_LIVE';
  setupPattern?: string;
}

export interface EaConfig {
  autoAnalyze: boolean;
  analyzeCadence: 'CANDLE_CLOSE' | '30S' | '60S' | '180S';
  autoExecute: boolean;
  minConfidence: number;
  lotMode: 'RISK_PERCENT' | 'FIXED_LOT';
  riskPercent: number;
  fixedLot: number;
  maxOpenPositions: number;
  maxDailyLossPercent: number;
  useTrailingStop: boolean;
  trailingAtrMultiplier: number;
  useBreakeven?: boolean;
  breakevenTriggerUsd?: number;
  fullAiControl?: boolean;
  strategyFocus: 'BALANCED' | 'SCALPING_EMA' | 'ULTRA_SCALP' | 'LIQUIDITY_SMC';
  initialBalance: number;
}

export interface Mt5AccountConfig {
  login: string;
  server: string;
  accountType: 'REAL' | 'DEMO';
  bridgeKey: string;
  configuredAt: number;
}

export interface Mt5LivePosition {
  ticket: number;
  symbol: string;
  side: 'BUY' | 'SELL';
  lots: number;
  openPrice: number;
  sl: number;
  tp: number;
  profit: number;
  openTime: number;
}

export interface Mt5BridgeStatus {
  configured: boolean;
  connected: boolean;
  profile: Mt5AccountConfig | null;
  lastHeartbeatAt: number | null;
  liveAccount: {
    login: string;
    server: string;
    company: string;
    currency: string;
    balance: number;
    equity: number;
    margin: number;
    freeMargin: number;
    leverage: number;
    tradeAllowed: boolean;
    positions: Mt5LivePosition[];
  } | null;
  pendingCommandsCount: number;
}

export interface RiskNotification {
  id: string;
  timestamp: number;
  level: 'INFO' | 'WARNING' | 'CRITICAL';
  title: string;
  message: string;
  tradeRiskPercent: number;
  tradeRiskUsd: number;
  totalExposurePercent: number;
}
