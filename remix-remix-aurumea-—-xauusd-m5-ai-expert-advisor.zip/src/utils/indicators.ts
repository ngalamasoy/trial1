import type { Candle, IndicatorSnapshot } from '../types/trading.ts';

export function computeEmaArray(values: number[], period: number): Array<number | null> {
  const result: Array<number | null> = new Array(values.length).fill(null);
  if (values.length < period) return result;

  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += values[i];
  }
  let prevEma = sum / period;
  result[period - 1] = Number(prevEma.toFixed(2));

  const k = 2 / (period + 1);
  for (let i = period; i < values.length; i++) {
    prevEma = values[i] * k + prevEma * (1 - k);
    result[i] = Number(prevEma.toFixed(2));
  }
  return result;
}

export function computeRsi14(closes: number[], period = 14): number | null {
  if (closes.length <= period) return null;

  let gains = 0;
  let losses = 0;
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gains += diff;
    else losses += Math.abs(diff);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? Math.abs(diff) : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return Number((100 - 100 / (1 + rs)).toFixed(2));
}

export function computeMacd(closes: number[]): {
  line: number | null;
  signal: number | null;
  histogram: number | null;
} {
  if (closes.length < 35) {
    return { line: null, signal: null, histogram: null };
  }

  const ema12 = computeEmaArray(closes, 12);
  const ema26 = computeEmaArray(closes, 26);

  const macdValues: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    const fast = ema12[i];
    const slow = ema26[i];
    if (fast !== null && slow !== null) {
      macdValues.push(fast - slow);
    }
  }

  if (macdValues.length < 9) {
    return { line: null, signal: null, histogram: null };
  }

  const signalArr = computeEmaArray(macdValues, 9);
  const lastMacd = macdValues[macdValues.length - 1];
  const lastSignal = signalArr[signalArr.length - 1];

  if (lastSignal === null) {
    return { line: Number(lastMacd.toFixed(3)), signal: null, histogram: null };
  }

  return {
    line: Number(lastMacd.toFixed(3)),
    signal: Number(lastSignal.toFixed(3)),
    histogram: Number((lastMacd - lastSignal).toFixed(3)),
  };
}

export function computeAtr14(candles: Candle[], period = 14): number | null {
  if (candles.length <= period) return null;

  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const cur = candles[i];
    const prev = candles[i - 1];
    const tr = Math.max(
      cur.high - cur.low,
      Math.abs(cur.high - prev.close),
      Math.abs(cur.low - prev.close)
    );
    trs.push(tr);
  }

  let atr = 0;
  for (let i = 0; i < period; i++) {
    atr += trs[i];
  }
  atr /= period;

  for (let i = period; i < trs.length; i++) {
    atr = (atr * (period - 1) + trs[i]) / period;
  }

  return Number(atr.toFixed(2));
}

export function computeBollingerSeries(
  candles: Candle[],
  period = 20,
  mult = 2
): {
  upperSeries: Array<{ time: number; value: number }>;
  lowerSeries: Array<{ time: number; value: number }>;
  latest: { upper: number | null; middle: number | null; lower: number | null };
} {
  const upperSeries: Array<{ time: number; value: number }> = [];
  const lowerSeries: Array<{ time: number; value: number }> = [];
  let latest: { upper: number | null; middle: number | null; lower: number | null } = {
    upper: null,
    middle: null,
    lower: null,
  };

  if (candles.length < period) {
    return { upperSeries, lowerSeries, latest };
  }

  for (let i = period - 1; i < candles.length; i++) {
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) {
      sum += candles[j].close;
    }
    const mean = sum / period;

    let sqDiffSum = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const diff = candles[j].close - mean;
      sqDiffSum += diff * diff;
    }
    const stdDev = Math.sqrt(sqDiffSum / period);

    const upper = Number((mean + mult * stdDev).toFixed(2));
    const lower = Number((mean - mult * stdDev).toFixed(2));
    const middle = Number(mean.toFixed(2));

    upperSeries.push({ time: candles[i].time, value: upper });
    lowerSeries.push({ time: candles[i].time, value: lower });
    if (i === candles.length - 1) {
      latest = { upper, middle, lower };
    }
  }

  return { upperSeries, lowerSeries, latest };
}

export function buildIndicatorPack(candles: Candle[]): {
  snapshot: IndicatorSnapshot;
  ema9Series: Array<{ time: number; value: number }>;
  ema21Series: Array<{ time: number; value: number }>;
  ema50Series: Array<{ time: number; value: number }>;
  bbUpperSeries: Array<{ time: number; value: number }>;
  bbLowerSeries: Array<{ time: number; value: number }>;
} {
  const closes = candles.map((c) => c.close);
  const ema9Arr = computeEmaArray(closes, 9);
  const ema21Arr = computeEmaArray(closes, 21);
  const ema50Arr = computeEmaArray(closes, 50);
  const ema200Arr = computeEmaArray(closes, 200);

  const ema9Series: Array<{ time: number; value: number }> = [];
  const ema21Series: Array<{ time: number; value: number }> = [];
  const ema50Series: Array<{ time: number; value: number }> = [];

  for (let i = 0; i < candles.length; i++) {
    const t = candles[i].time;
    if (ema9Arr[i] !== null) ema9Series.push({ time: t, value: ema9Arr[i]! });
    if (ema21Arr[i] !== null) ema21Series.push({ time: t, value: ema21Arr[i]! });
    if (ema50Arr[i] !== null) ema50Series.push({ time: t, value: ema50Arr[i]! });
  }

  const bb = computeBollingerSeries(candles, 20, 2);
  const lookback = candles.slice(-30);
  const swingHigh = lookback.length > 0 ? Math.max(...lookback.map((c) => c.high)) : 0;
  const swingLow = lookback.length > 0 ? Math.min(...lookback.map((c) => c.low)) : 0;

  const lastIdx = candles.length - 1;
  const snapshot: IndicatorSnapshot = {
    ema9: lastIdx >= 0 ? ema9Arr[lastIdx] : null,
    ema21: lastIdx >= 0 ? ema21Arr[lastIdx] : null,
    ema50: lastIdx >= 0 ? ema50Arr[lastIdx] : null,
    ema200: lastIdx >= 0 ? ema200Arr[lastIdx] : null,
    rsi14: computeRsi14(closes, 14),
    macd: computeMacd(closes),
    atr14: computeAtr14(candles, 14),
    bollinger: bb.latest,
    swingHigh: Number(swingHigh.toFixed(2)),
    swingLow: Number(swingLow.toFixed(2)),
  };

  return {
    snapshot,
    ema9Series,
    ema21Series,
    ema50Series,
    bbUpperSeries: bb.upperSeries,
    bbLowerSeries: bb.lowerSeries,
  };
}

export function calculateXauLotSize(
  balance: number,
  riskPercent: number,
  entryPrice: number,
  stopLoss: number
): number {
  const slDistance = Math.abs(entryPrice - stopLoss);
  if (slDistance < 0.25) return 0.01;
  const riskUsd = (balance * riskPercent) / 100;
  // Standard XAUUSD: 1.00 lot = 100 oz => $100 per $1.00 price move
  const rawLots = riskUsd / (slDistance * 100);
  const clamped = Math.max(0.01, Math.min(10.0, rawLots));
  return Number(clamped.toFixed(2));
}

export function calculateXauPnl(
  side: 'BUY' | 'SELL',
  lots: number,
  entryPrice: number,
  currentPrice: number
): number {
  const diff = side === 'BUY' ? currentPrice - entryPrice : entryPrice - currentPrice;
  return Number((diff * lots * 100).toFixed(2));
}
