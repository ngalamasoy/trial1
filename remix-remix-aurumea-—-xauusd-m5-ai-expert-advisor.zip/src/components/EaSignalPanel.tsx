import React from 'react';
import {
  ArrowDownRight,
  ArrowUpRight,
  Minus,
  Play,
  Square,
  AlertTriangle,
  Eye,
} from 'lucide-react';
import type {
  EaAnalysisResult,
  EaConfig,
  MarketQuote,
  Mt5BridgeStatus,
} from '../types/trading.ts';
import { calculateXauLotSize } from '../utils/indicators.ts';

interface EaSignalPanelProps {
  analysis: EaAnalysisResult | null;
  quote: MarketQuote | null;
  config: EaConfig;
  balance: number;
  atr14: number | null;
  totalExposurePercent: number;
  totalExposureUsd: number;
  mt5Status: Mt5BridgeStatus;
  isAnalyzing: boolean;
  analysisError: string | null;
  autoCountdownSec: number | null;
  onToggleAutoAnalyze: () => void;
  onToggleAutoExecute: () => void;
  onToggleFullAiControl: () => void;
  onAnalyzeNow: () => void;
  onExecuteAiSignal: () => void;
  onQuickMarketOrder: (side: 'BUY' | 'SELL') => void;
}

export const EaSignalPanel: React.FC<EaSignalPanelProps> = ({
  analysis,
  quote,
  config,
  balance,
  atr14,
  totalExposurePercent,
  totalExposureUsd,
  mt5Status,
  isAnalyzing,
  analysisError,
  autoCountdownSec,
  onToggleAutoAnalyze,
  onToggleAutoExecute,
  onToggleFullAiControl,
  onAnalyzeNow,
  onExecuteAiSignal,
  onQuickMarketOrder,
}) => {
  const isFullAiControl = config.fullAiControl ?? true;
  const signalColor =
    analysis?.signal === 'BUY'
      ? 'text-[#10B981]'
      : analysis?.signal === 'SELL'
      ? 'text-[#EF4444]'
      : 'text-[#F59E0B]';

  const suggestedLot =
    analysis && analysis.signal !== 'HOLD'
      ? config.lotMode === 'FIXED_LOT'
        ? config.fixedLot
        : calculateXauLotSize(balance, config.riskPercent, analysis.entryPrice, analysis.stopLoss)
      : config.fixedLot;

  // Compute exact % risk for the next order (AI signal if actionable, else market order)
  const atrVal = atr14 ?? 2.5;
  const isScalpMode =
    config.strategyFocus === 'SCALPING_EMA' || config.strategyFocus === 'ULTRA_SCALP';
  const strategyLabel =
    config.strategyFocus === 'ULTRA_SCALP'
      ? 'Ultra-Scalp M1+M5'
      : config.strategyFocus === 'SCALPING_EMA'
      ? 'Scalping EMA M5'
      : config.strategyFocus === 'LIQUIDITY_SMC'
      ? 'SMC Scalp M5'
      : 'Balanced M5';

  const previewRiskSlDist =
    analysis && analysis.signal !== 'HOLD'
      ? Math.abs(analysis.entryPrice - analysis.stopLoss)
      : Number((atrVal * (isScalpMode ? 1.0 : 1.5)).toFixed(2));
  const previewLot =
    analysis && analysis.signal !== 'HOLD'
      ? suggestedLot
      : config.lotMode === 'FIXED_LOT'
      ? config.fixedLot
      : calculateXauLotSize(balance, config.riskPercent, 0, previewRiskSlDist);
  const previewRiskUsd = Number((previewRiskSlDist * previewLot * 100).toFixed(2));
  const previewRiskPct = balance > 0 ? Number(((previewRiskUsd / balance) * 100).toFixed(2)) : 0;

  return (
    <aside className="flex flex-col bg-[#111620] border border-white/[0.08] rounded-lg overflow-hidden">
      {/* EA Automation Controls Header */}
      <div className="p-4 border-b border-white/[0.08] space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-[#F8FAFC]">
              Gemini Expert Advisor
            </h2>
            <p className="text-xs text-[#94A3B8] mt-0.5">
              {mt5Status.connected
                ? `MT5 #${mt5Status.profile?.login}`
                : 'Simulasi Web'}{' '}
              · <span className="text-[#D4AF37]">{strategyLabel}</span>
              {autoCountdownSec !== null && config.autoAnalyze
                ? ` · ${autoCountdownSec}d`
                : ''}
            </p>
          </div>
          <button
            type="button"
            onClick={onToggleAutoAnalyze}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border transition-colors whitespace-nowrap shrink-0 ${
              config.autoAnalyze
                ? 'bg-[#10B981]/15 text-[#10B981] border-[#10B981]/40'
                : 'bg-[#161C28] text-[#94A3B8] border-white/[0.08] hover:text-[#F8FAFC]'
            }`}
          >
            {config.autoAnalyze ? (
              <>
                <Square className="w-3 h-3 fill-current" />
                <span>Auto Scan Aktif</span>
              </>
            ) : (
              <>
                <Play className="w-3 h-3 fill-current" />
                <span>Mulai Auto Scan</span>
              </>
            )}
          </button>
        </div>

        {/* Auto-Execution & 100% AI Judge Switches */}
        <div className="space-y-2 pt-2 border-t border-white/[0.06] text-xs">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[#E6EDF3] font-medium">AI Hakim Keputusan</span>
              <span className="text-[#D4AF37] ml-1.5 font-medium">
                {isFullAiControl ? '(100% Kendali AI)' : '(Filter Conf)'}
              </span>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={isFullAiControl}
              onClick={onToggleFullAiControl}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border transition-colors ${
                isFullAiControl
                  ? 'bg-[#10B981] border-[#10B981]'
                  : 'bg-[#1E293B] border-white/15'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-[#0B0E14] transition-transform ${
                  isFullAiControl ? 'translate-x-4' : 'translate-x-0.5'
                } mt-[1px]`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <span className="text-[#E6EDF3] font-medium">Auto Eksekusi Order</span>
              <span className="text-[#94A3B8] ml-1.5">
                {isFullAiControl ? '(Langsung ikut vonis AI)' : `(Conf ≥ ${config.minConfidence}%)`}
              </span>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={config.autoExecute}
              onClick={onToggleAutoExecute}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border transition-colors ${
                config.autoExecute
                  ? 'bg-[#D4AF37] border-[#D4AF37]'
                  : 'bg-[#1E293B] border-white/15'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-[#0B0E14] transition-transform ${
                  config.autoExecute ? 'translate-x-4' : 'translate-x-0.5'
                } mt-[1px]`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Error State */}
      {analysisError && (
        <div className="mx-4 mt-4 p-3 rounded-md bg-[#EF4444]/10 border border-[#EF4444]/30 text-xs text-[#FCA5A5] flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-[#EF4444] shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold text-[#EF4444]">Analisa Gemini Gagal</p>
            <p className="leading-relaxed">{analysisError}</p>
          </div>
        </div>
      )}

      {/* Main Signal Readout */}
      <div className="p-4 flex-1 flex flex-col justify-between gap-4">
        {!analysis ? (
          <div className="py-10 text-center space-y-3">
            <p className="text-sm font-medium text-[#E6EDF3]">
              Siap Menganalisa Chart M5
            </p>
            <p className="text-xs text-[#94A3B8] leading-relaxed max-w-xs mx-auto">
              Klik <strong className="text-[#F8FAFC]">Analisa Chart</strong> untuk mengirim snapshot visual chart candlestick dan data indikator teknikal M5 ke endpoint Gemini.
            </p>
            <button
              type="button"
              onClick={onAnalyzeNow}
              disabled={isAnalyzing}
              className="px-4 py-2 text-xs font-semibold rounded-md bg-[#D4AF37] text-[#0B0E14] hover:bg-[#E5B842] disabled:opacity-60 transition-colors"
            >
              {isAnalyzing ? 'Sedang Menganalisa...' : 'Jalankan Analisa Pertama'}
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Signal Header */}
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  {analysis.signal === 'BUY' && (
                    <ArrowUpRight className="w-5 h-5 text-[#10B981]" />
                  )}
                  {analysis.signal === 'SELL' && (
                    <ArrowDownRight className="w-5 h-5 text-[#EF4444]" />
                  )}
                  {analysis.signal === 'HOLD' && (
                    <Minus className="w-5 h-5 text-[#F59E0B]" />
                  )}
                  <span className={`text-2xl font-bold tracking-tight ${signalColor}`}>
                    {analysis.signal}
                  </span>
                  <span className="text-xs text-[#94A3B8] font-mono tabular-nums ml-1">
                    {analysis.confidence}% confidence
                  </span>
                </div>
                <p className="text-xs text-[#94A3B8] mt-1">
                  Bias {analysis.marketBias} · {analysis.setupPattern}
                </p>
              </div>

              <div className="text-right font-mono tabular-nums text-[11px] text-[#94A3B8]">
                <div>{new Date(analysis.timestamp).toLocaleTimeString('id-ID')}</div>
                <div className="inline-flex items-center gap-1 justify-end mt-0.5">
                  {analysis.usedChartVision && <Eye className="w-3 h-3 text-[#D4AF37]" />}
                  <span>{analysis.latencyMs} ms</span>
                </div>
              </div>
            </div>

            {/* Price Matrix */}
            <div className="grid grid-cols-2 gap-px bg-white/[0.08] border border-white/[0.08] rounded-md overflow-hidden font-mono tabular-nums text-xs">
              <div className="bg-[#0B0E14] p-2.5">
                <div className="text-[#94A3B8] text-[11px]">Entry Referensi</div>
                <div className="text-[#F8FAFC] font-semibold mt-0.5">
                  {analysis.entryPrice.toFixed(2)}
                </div>
              </div>
              <div className="bg-[#0B0E14] p-2.5">
                <div className="text-[#94A3B8] text-[11px]">Stop Loss</div>
                <div className="text-[#EF4444] font-semibold mt-0.5">
                  {analysis.stopLoss.toFixed(2)}
                </div>
              </div>
              <div className="bg-[#0B0E14] p-2.5">
                <div className="text-[#94A3B8] text-[11px]">Take Profit 1</div>
                <div className="text-[#10B981] font-semibold mt-0.5">
                  {analysis.takeProfit1.toFixed(2)}
                </div>
              </div>
              <div className="bg-[#0B0E14] p-2.5">
                <div className="text-[#94A3B8] text-[11px]">TP2 / Risk:Reward</div>
                <div className="text-[#10B981] font-semibold mt-0.5">
                  {analysis.takeProfit2.toFixed(2)}{' '}
                  <span className="text-[#94A3B8] font-normal">({analysis.riskRewardRatio})</span>
                </div>
              </div>
            </div>

            {/* AI Judge Verdict + Indicator Weighting */}
            {(analysis.judgeVerdict || analysis.indicatorWeighting) && (
              <div className="p-2.5 rounded-md bg-[#0B0E14] border border-[#D4AF37]/30 space-y-1.5 text-xs">
                {analysis.judgeVerdict && (
                  <div className="font-semibold text-[#F8FAFC] leading-snug">
                    {analysis.judgeVerdict}
                  </div>
                )}
                {analysis.indicatorWeighting && (
                  <p className="text-[11px] text-[#94A3B8] leading-relaxed">
                    <span className="text-[#D4AF37] font-medium">Timbangan Indikator: </span>
                    {analysis.indicatorWeighting}
                  </p>
                )}
              </div>
            )}

            {/* Summary & Technical Factors */}
            <div className="space-y-2.5 text-xs">
              <p className="text-[#E6EDF3] leading-relaxed">{analysis.summary}</p>
              {analysis.keyFactors.length > 0 && (
                <ul className="space-y-1.5 text-[#94A3B8] pt-1 border-t border-white/[0.06]">
                  {analysis.keyFactors.map((factor, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#D4AF37] font-mono">0{idx + 1}.</span>
                      <span className="leading-snug">{factor}</span>
                    </li>
                  ))}
                </ul>
              )}
              <div className="pt-2 border-t border-white/[0.06] text-[11px] text-[#94A3B8]">
                <span className="text-[#E6EDF3] font-medium">Invalidasi: </span>
                {analysis.invalidatedIf}
              </div>
            </div>
          </div>
        )}

        {/* Order Execution Footer + Live % Risk Preview */}
        <div className="pt-3 border-t border-white/[0.08] space-y-2.5">
          <div className="p-2.5 rounded bg-[#0B0E14] border border-white/[0.08] flex items-center justify-between text-[11px] font-mono tabular-nums">
            <div>
              <span className="text-[#94A3B8]">Risk Order: </span>
              <strong
                className={
                  previewRiskPct > 2.5
                    ? 'text-[#EF4444]'
                    : previewRiskPct > 1.5
                    ? 'text-[#F59E0B]'
                    : 'text-[#10B981]'
                }
              >
                {previewRiskPct.toFixed(2)}%
              </strong>
              <span className="text-[#94A3B8] ml-1">(${previewRiskUsd.toFixed(2)})</span>
            </div>
            <div>
              <span className="text-[#94A3B8]">Aktif: </span>
              <strong
                className={
                  totalExposurePercent >= config.maxDailyLossPercent
                    ? 'text-[#EF4444]'
                    : totalExposurePercent >= 2.5
                    ? 'text-[#F59E0B]'
                    : 'text-[#E6EDF3]'
                }
              >
                {totalExposurePercent.toFixed(2)}%
              </strong>
              <span className="text-[#94A3B8] ml-1">(${totalExposureUsd.toFixed(2)})</span>
            </div>
          </div>

          {analysis && analysis.signal !== 'HOLD' && (
            <button
              type="button"
              onClick={onExecuteAiSignal}
              disabled={!quote}
              className={`w-full py-2.5 px-4 text-xs font-semibold rounded-md transition-colors disabled:opacity-50 ${
                analysis.signal === 'BUY'
                  ? 'bg-[#10B981] text-[#0B0E14] hover:bg-[#34D399]'
                  : 'bg-[#EF4444] text-white hover:bg-[#F87171]'
              }`}
            >
              Eksekusi {analysis.signal} AI ({suggestedLot.toFixed(2)} Lot · Risk {previewRiskPct.toFixed(2)}%)
            </button>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => onQuickMarketOrder('BUY')}
              disabled={!quote}
              className="py-2 px-3 text-xs font-semibold rounded-md border border-[#10B981]/40 bg-[#10B981]/10 text-[#10B981] hover:bg-[#10B981]/20 disabled:opacity-40 transition-colors font-mono tabular-nums"
            >
              Buy {quote ? quote.ask.toFixed(2) : '--'}
            </button>
            <button
              type="button"
              onClick={() => onQuickMarketOrder('SELL')}
              disabled={!quote}
              className="py-2 px-3 text-xs font-semibold rounded-md border border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444] hover:bg-[#EF4444]/20 disabled:opacity-40 transition-colors font-mono tabular-nums"
            >
              Sell {quote ? quote.bid.toFixed(2) : '--'}
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};
