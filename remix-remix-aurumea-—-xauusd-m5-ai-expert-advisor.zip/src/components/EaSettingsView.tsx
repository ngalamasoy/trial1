import React from 'react';
import { RotateCcw, Zap } from 'lucide-react';
import type { EaConfig } from '../types/trading.ts';

interface EaSettingsViewProps {
  config: EaConfig;
  onUpdateConfig: (patch: Partial<EaConfig>) => void;
  onResetAccount: () => void;
}

export const EaSettingsView: React.FC<EaSettingsViewProps> = ({
  config,
  onUpdateConfig,
  onResetAccount,
}) => {
  const applyScalpingPreset = () => {
    onUpdateConfig({
      strategyFocus: 'SCALPING_EMA',
      analyzeCadence: '30S',
      fullAiControl: true,
      minConfidence: 76,
      useTrailingStop: true,
      trailingAtrMultiplier: 0.9,
      useBreakeven: true,
      breakevenTriggerUsd: 1.2,
      maxOpenPositions: 2,
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-4 lg:p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/[0.08] pb-4">
        <div>
          <h1 className="text-xl font-semibold text-[#F8FAFC]">
            Parameter Expert Advisor XAU/USD M5
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Atur manajemen risiko, interval pemindaian Gemini, strategi scalping, dan proteksi breakeven/trailing.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={applyScalpingPreset}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-md bg-[#D4AF37]/15 border border-[#D4AF37]/50 text-[#D4AF37] hover:bg-[#D4AF37]/25 transition-colors"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Preset Fokus Scalping</span>
          </button>
          <button
            type="button"
            onClick={onResetAccount}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-md border border-white/[0.1] bg-[#111620] text-[#E6EDF3] hover:bg-[#161C28] transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Saldo &amp; Riwayat</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Strategi & Frekuensi Gemini */}
        <section className="bg-[#111620] border border-white/[0.08] rounded-lg p-5 space-y-4">
          <h2 className="text-sm font-semibold text-[#F8FAFC] border-b border-white/[0.06] pb-2.5">
            Strategi &amp; Jadwal Analisa Gemini
          </h2>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-[#E6EDF3]">
              Fokus Strategi M5 / M1
            </label>
            <select
              value={config.strategyFocus}
              onChange={(e) =>
                onUpdateConfig({
                  strategyFocus: e.target.value as EaConfig['strategyFocus'],
                })
              }
              className="w-full px-3 py-2 text-xs rounded-md bg-[#0B0E14] border border-white/[0.1] text-[#F8FAFC] focus:outline-none focus:border-[#D4AF37]"
            >
              <option value="SCALPING_EMA">Scalping Momentum M5 (EMA 9/21/50 + Tight ATR)</option>
              <option value="ULTRA_SCALP">Ultra-Scalping M1 + M5 (Sniper Micro Breakout)</option>
              <option value="LIQUIDITY_SMC">Smart Money Concepts (Liquidity Sweep &amp; BOS)</option>
              <option value="BALANCED">Balanced Confluence (EMA + RSI + MACD + Price Action)</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-[#E6EDF3]">
              Interval Auto-Scan Chart
            </label>
            <select
              value={config.analyzeCadence}
              onChange={(e) =>
                onUpdateConfig({
                  analyzeCadence: e.target.value as EaConfig['analyzeCadence'],
                })
              }
              className="w-full px-3 py-2 text-xs rounded-md bg-[#0B0E14] border border-white/[0.1] text-[#F8FAFC] focus:outline-none focus:border-[#D4AF37]"
            >
              <option value="30S">Setiap 30 Detik (Rekomendasi Scalping)</option>
              <option value="60S">Setiap 60 Detik (Candle M1)</option>
              <option value="180S">Setiap 3 Menit</option>
              <option value="CANDLE_CLOSE">Setiap Candle M5 Tutup (5 Menit)</option>
            </select>
          </div>

          <div className="p-3 rounded-md bg-[#0B0E14] border border-[#10B981]/30 flex items-center justify-between gap-3 text-xs">
            <div>
              <span className="font-semibold text-[#F8FAFC]">
                AI Hakim Keputusan (100% Kendali AI)
              </span>
              <p className="text-[11px] text-[#94A3B8] mt-0.5 leading-relaxed">
                Indikator hanya menjadi data mentah. Vonis <strong className="text-[#E6EDF3]">HOLD / BUY / SELL</strong> diputuskan 100% oleh AI tanpa diblokir filter confidence lokal.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={config.fullAiControl ?? true}
              onClick={() => onUpdateConfig({ fullAiControl: !(config.fullAiControl ?? true) })}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border transition-colors ${
                (config.fullAiControl ?? true)
                  ? 'bg-[#10B981] border-[#10B981]'
                  : 'bg-[#1E293B] border-white/15'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-[#0B0E14] transition-transform ${
                  (config.fullAiControl ?? true) ? 'translate-x-4' : 'translate-x-0.5'
                } mt-[1px]`}
              />
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <label className="font-medium text-[#E6EDF3]">
                Minimum Confidence Auto-Eksekusi
              </label>
              <span className="font-mono tabular-nums text-[#D4AF37]">
                {(config.fullAiControl ?? true) ? 'Bypass (100% AI)' : `${config.minConfidence}%`}
              </span>
            </div>
            <input
              type="range"
              min={55}
              max={95}
              step={1}
              disabled={config.fullAiControl ?? true}
              value={config.minConfidence}
              onChange={(e) => onUpdateConfig({ minConfidence: Number(e.target.value) })}
              className="w-full accent-[#D4AF37] disabled:opacity-40"
            />
            <p className="text-[11px] text-[#94A3B8]">
              {(config.fullAiControl ?? true)
                ? 'Nonaktifkan "100% Kendali AI" di atas jika ingin membatasi eksekusi dengan threshold confidence manual.'
                : 'EA hanya mengeksekusi order otomatis jika skor keyakinan Gemini memenuhi ambang batas ini.'}
            </p>
          </div>

          <div className="space-y-1.5 pt-2 border-t border-white/[0.06]">
            <div className="flex items-center justify-between text-xs">
              <label className="font-medium text-[#E6EDF3]">
                Pengali ATR Trailing Stop
              </label>
              <span className="font-mono tabular-nums text-[#D4AF37]">
                {config.trailingAtrMultiplier.toFixed(1)}x ATR
              </span>
            </div>
            <input
              type="range"
              min={0.5}
              max={2.5}
              step={0.1}
              value={config.trailingAtrMultiplier}
              onChange={(e) =>
                onUpdateConfig({ trailingAtrMultiplier: Number(e.target.value) })
              }
              className="w-full accent-[#D4AF37]"
            />
            <p className="text-[11px] text-[#94A3B8]">
              Untuk scalping cepat XAU/USD disarankan 0.8x - 1.0x ATR agar profit cepat terkunci.
            </p>
          </div>
        </section>

        {/* Risk & Position Sizing */}
        <section className="bg-[#111620] border border-white/[0.08] rounded-lg p-5 space-y-4">
          <h2 className="text-sm font-semibold text-[#F8FAFC] border-b border-white/[0.06] pb-2.5">
            Manajemen Risiko &amp; Proteksi Scalping
          </h2>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-[#E6EDF3]">
              Metode Ukuran Lot
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onUpdateConfig({ lotMode: 'RISK_PERCENT' })}
                className={`py-2 px-3 text-xs font-medium rounded-md border transition-colors ${
                  config.lotMode === 'RISK_PERCENT'
                    ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#F8FAFC]'
                    : 'bg-[#0B0E14] border-white/[0.08] text-[#94A3B8]'
                }`}
              >
                Dinamis (% Risk)
              </button>
              <button
                type="button"
                onClick={() => onUpdateConfig({ lotMode: 'FIXED_LOT' })}
                className={`py-2 px-3 text-xs font-medium rounded-md border transition-colors ${
                  config.lotMode === 'FIXED_LOT'
                    ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#F8FAFC]'
                    : 'bg-[#0B0E14] border-white/[0.08] text-[#94A3B8]'
                }`}
              >
                Fixed Lot
              </button>
            </div>
          </div>

          {config.lotMode === 'RISK_PERCENT' ? (
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-[#E6EDF3]">
                Risiko Per Trade (% dari Balance)
              </label>
              <input
                type="number"
                min={0.1}
                max={5}
                step={0.1}
                value={config.riskPercent}
                onChange={(e) =>
                  onUpdateConfig({ riskPercent: Math.max(0.1, Number(e.target.value) || 1) })
                }
                className="w-full px-3 py-2 text-xs font-mono tabular-nums rounded-md bg-[#0B0E14] border border-white/[0.1] text-[#F8FAFC] focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          ) : (
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-[#E6EDF3]">
                Ukuran Lot Tetap (Standard 1.00 = 100 oz)
              </label>
              <input
                type="number"
                min={0.01}
                max={10}
                step={0.01}
                value={config.fixedLot}
                onChange={(e) =>
                  onUpdateConfig({ fixedLot: Math.max(0.01, Number(e.target.value) || 0.05) })
                }
                className="w-full px-3 py-2 text-xs font-mono tabular-nums rounded-md bg-[#0B0E14] border border-white/[0.1] text-[#F8FAFC] focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-[#E6EDF3]">
                Max Posisi Terbuka
              </label>
              <input
                type="number"
                min={1}
                max={10}
                value={config.maxOpenPositions}
                onChange={(e) =>
                  onUpdateConfig({
                    maxOpenPositions: Math.max(1, Math.min(10, Number(e.target.value) || 1)),
                  })
                }
                className="w-full px-3 py-2 text-xs font-mono tabular-nums rounded-md bg-[#0B0E14] border border-white/[0.1] text-[#F8FAFC] focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-[#E6EDF3]">
                Batas Rugi Harian (%)
              </label>
              <input
                type="number"
                min={1}
                max={25}
                step={0.5}
                value={config.maxDailyLossPercent}
                onChange={(e) =>
                  onUpdateConfig({
                    maxDailyLossPercent: Math.max(1, Number(e.target.value) || 5),
                  })
                }
                className="w-full px-3 py-2 text-xs font-mono tabular-nums rounded-md bg-[#0B0E14] border border-white/[0.1] text-[#F8FAFC] focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          </div>

          <div className="pt-2 border-t border-white/[0.06] flex items-center justify-between text-xs gap-3">
            <div>
              <span className="font-medium text-[#E6EDF3]">Auto Breakeven+ Scalping</span>
              <p className="text-[11px] text-[#94A3B8]">
                Kunci SL ke entry +$0.20 saat profit mencapai ${(config.breakevenTriggerUsd ?? 1.2).toFixed(2)}
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={config.useBreakeven ?? true}
              onClick={() => onUpdateConfig({ useBreakeven: !(config.useBreakeven ?? true) })}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border transition-colors ${
                (config.useBreakeven ?? true)
                  ? 'bg-[#D4AF37] border-[#D4AF37]'
                  : 'bg-[#1E293B] border-white/15'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-[#0B0E14] transition-transform ${
                  (config.useBreakeven ?? true) ? 'translate-x-4' : 'translate-x-0.5'
                } mt-[1px]`}
              />
            </button>
          </div>

          <div className="pt-2 border-t border-white/[0.06] flex items-center justify-between text-xs gap-3">
            <div>
              <span className="font-medium text-[#E6EDF3]">ATR Trailing Stop Otomatis</span>
              <p className="text-[11px] text-[#94A3B8]">
                Geser Stop Loss otomatis ke profit saat harga bergerak &ge; {config.trailingAtrMultiplier}x ATR
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={config.useTrailingStop}
              onClick={() => onUpdateConfig({ useTrailingStop: !config.useTrailingStop })}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border transition-colors ${
                config.useTrailingStop
                  ? 'bg-[#D4AF37] border-[#D4AF37]'
                  : 'bg-[#1E293B] border-white/15'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-[#0B0E14] transition-transform ${
                  config.useTrailingStop ? 'translate-x-4' : 'translate-x-0.5'
                } mt-[1px]`}
              />
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
