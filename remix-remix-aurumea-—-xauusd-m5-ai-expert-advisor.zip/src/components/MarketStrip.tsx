import React from 'react';
import type {
  IndicatorSnapshot,
  MarketQuote,
  Mt5BridgeStatus,
} from '../types/trading.ts';

interface MarketStripProps {
  quote: MarketQuote | null;
  indicators: IndicatorSnapshot | null;
  balance: number;
  equity: number;
  floatingPnl: number;
  totalExposurePercent: number;
  mt5Status: Mt5BridgeStatus;
  streamConnected: boolean;
}

function formatCountdown(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const MarketStrip: React.FC<MarketStripProps> = ({
  quote,
  indicators,
  balance,
  equity,
  floatingPnl,
  totalExposurePercent,
  mt5Status,
  streamConnected,
}) => {
  const isPositiveChange = (quote?.change24h ?? 0) >= 0;
  const isPositiveFloating = floatingPnl >= 0;

  return (
    <section
      aria-label="Ringkasan pasar dan akun"
      className="border-b border-white/[0.08] bg-[#111620] px-4 lg:px-6 py-2.5 flex flex-wrap items-center justify-between gap-x-8 gap-y-2 text-xs"
    >
      {/* Left: Pair, Live Bid/Ask, Spread, 24h Change, Candle Countdown */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-1.5">
        <div className="flex items-baseline gap-2 whitespace-nowrap">
          <span className="text-sm font-bold text-[#F8FAFC]">XAU/USD</span>
          <span className="text-[#94A3B8]">·</span>
          <span className="font-mono text-[#D4AF37] font-semibold">M5</span>
          <span className="text-[#94A3B8]">·</span>
          <span className="text-[#94A3B8]">
            {streamConnected ? quote?.source || 'Tersambung' : 'Menghubungkan feed...'}
          </span>
        </div>

        <div className="h-3.5 w-px bg-white/[0.08] hidden sm:block" />

        <div className="flex items-center gap-5 font-mono tabular-nums whitespace-nowrap">
          <div>
            <span className="text-[#94A3B8] mr-1.5">Bid</span>
            <span className="text-sm font-semibold text-[#F8FAFC]">
              {quote ? quote.bid.toFixed(2) : '----.--'}
            </span>
          </div>
          <div>
            <span className="text-[#94A3B8] mr-1.5">Ask</span>
            <span className="text-sm font-semibold text-[#F8FAFC]">
              {quote ? quote.ask.toFixed(2) : '----.--'}
            </span>
          </div>
          <div>
            <span className="text-[#94A3B8] mr-1.5">Spread</span>
            <span className="text-[#E6EDF3]">
              {quote ? `$${quote.spread.toFixed(2)}` : '--'}
            </span>
          </div>
          <div>
            <span className="text-[#94A3B8] mr-1.5">24j</span>
            <span className={isPositiveChange ? 'text-[#10B981]' : 'text-[#EF4444]'}>
              {quote
                ? `${isPositiveChange ? '+' : ''}${quote.change24h.toFixed(2)} (${
                    isPositiveChange ? '+' : ''
                  }${quote.changePercent24h.toFixed(2)}%)`
                : '--'}
            </span>
          </div>
          <div>
            <span className="text-[#94A3B8] mr-1.5">Tutup M5</span>
            <span className="text-[#E6EDF3]">
              {quote ? formatCountdown(quote.candleCloseInSec) : '--:--'}
            </span>
          </div>
          {indicators?.atr14 !== null && indicators?.atr14 !== undefined && (
            <div className="hidden xl:block">
              <span className="text-[#94A3B8] mr-1.5">ATR14</span>
              <span className="text-[#E6EDF3]">${indicators.atr14.toFixed(2)}</span>
            </div>
          )}
          {indicators?.rsi14 !== null && indicators?.rsi14 !== undefined && (
            <div className="hidden xl:block">
              <span className="text-[#94A3B8] mr-1.5">RSI14</span>
              <span
                className={
                  indicators.rsi14 >= 70
                    ? 'text-[#EF4444]'
                    : indicators.rsi14 <= 30
                    ? 'text-[#10B981]'
                    : 'text-[#E6EDF3]'
                }
              >
                {indicators.rsi14.toFixed(1)}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Right: Account Mode, Risk Exposure %, Balance, Equity, Floating P&L */}
      <div className="flex flex-wrap items-center gap-5 font-mono tabular-nums whitespace-nowrap">
        <div className="font-sans">
          <span className="text-[#94A3B8] mr-1.5">Akun</span>
          <span
            className={
              mt5Status.connected
                ? 'font-semibold text-[#10B981]'
                : 'font-medium text-[#E6EDF3]'
            }
          >
            {mt5Status.connected
              ? `MT5 ${mt5Status.profile?.accountType} #${mt5Status.profile?.login}`
              : mt5Status.configured
              ? `MT5 Menunggu EA`
              : 'Simulasi Web'}
          </span>
        </div>
        <div>
          <span className="text-[#94A3B8] mr-1.5">Risk Aktif</span>
          <span
            className={`font-semibold ${
              totalExposurePercent >= 4
                ? 'text-[#EF4444]'
                : totalExposurePercent >= 2
                ? 'text-[#F59E0B]'
                : 'text-[#10B981]'
            }`}
          >
            {totalExposurePercent.toFixed(2)}%
          </span>
        </div>
        <div>
          <span className="text-[#94A3B8] mr-1.5">Balance</span>
          <span className="font-semibold text-[#F8FAFC]">
            ${balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
        <div>
          <span className="text-[#94A3B8] mr-1.5">Equity</span>
          <span className="font-semibold text-[#F8FAFC]">
            ${equity.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
        <div>
          <span className="text-[#94A3B8] mr-1.5">Floating</span>
          <span
            className={`font-semibold ${
              floatingPnl === 0
                ? 'text-[#94A3B8]'
                : isPositiveFloating
                ? 'text-[#10B981]'
                : 'text-[#EF4444]'
            }`}
          >
            {floatingPnl >= 0 ? '+' : '-'}${Math.abs(floatingPnl).toFixed(2)}
          </span>
        </div>
      </div>
    </section>
  );
};
