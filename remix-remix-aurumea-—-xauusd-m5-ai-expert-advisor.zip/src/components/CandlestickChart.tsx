import React, { useEffect, useImperativeHandle, useRef, useState, forwardRef } from 'react';
import {
  CandlestickSeries,
  ColorType,
  CrosshairMode,
  LineSeries,
  LineStyle,
  createChart,
  type IChartApi,
  type IPriceLine,
  type ISeriesApi,
  type UTCTimestamp,
} from 'lightweight-charts';
import type { EaAnalysisResult, MarketSnapshot, OpenPosition } from '../types/trading.ts';

export interface CandlestickChartHandle {
  captureChartImage: () => string | null;
}

interface CandlestickChartProps {
  snapshot: MarketSnapshot | null;
  latestAnalysis: EaAnalysisResult | null;
  openPositions: OpenPosition[];
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}

export const CandlestickChart = forwardRef<CandlestickChartHandle, CandlestickChartProps>(
  ({ snapshot, latestAnalysis, openPositions, loading, error, onRetry }, ref) => {
    const containerRef = useRef<HTMLDivElement | null>(null);
    const chartRef = useRef<IChartApi | null>(null);
    const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
    const ema9SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
    const ema21SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
    const ema50SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
    const bbUpperRef = useRef<ISeriesApi<'Line'> | null>(null);
    const bbLowerRef = useRef<ISeriesApi<'Line'> | null>(null);
    const priceLinesRef = useRef<IPriceLine[]>([]);
    const hasFittedRef = useRef(false);

    const [showEmas, setShowEmas] = useState(true);
    const [showBollinger, setShowBollinger] = useState(false);
    const [showAiLevels, setShowAiLevels] = useState(true);
    const [hoveredCandle, setHoveredCandle] = useState<{
      open: number;
      high: number;
      low: number;
      close: number;
    } | null>(null);

    useImperativeHandle(ref, () => ({
      captureChartImage: () => {
        if (!chartRef.current) return null;
        try {
          const canvas = chartRef.current.takeScreenshot(true, false);
          return canvas.toDataURL('image/png');
        } catch {
          return null;
        }
      },
    }));

    // Initialize chart once
    useEffect(() => {
      const el = containerRef.current;
      if (!el) return;

      const chart = createChart(el, {
        layout: {
          background: { type: ColorType.Solid, color: '#0B0E14' },
          textColor: '#94A3B8',
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 11,
        },
        grid: {
          vertLines: { color: 'rgba(255, 255, 255, 0.04)' },
          horzLines: { color: 'rgba(255, 255, 255, 0.04)' },
        },
        crosshair: {
          mode: CrosshairMode.Normal,
          vertLine: {
            color: 'rgba(212, 175, 55, 0.45)',
            width: 1,
            style: LineStyle.Dashed,
            labelBackgroundColor: '#1E293B',
          },
          horzLine: {
            color: 'rgba(212, 175, 55, 0.45)',
            width: 1,
            style: LineStyle.Dashed,
            labelBackgroundColor: '#1E293B',
          },
        },
        rightPriceScale: {
          borderColor: 'rgba(255, 255, 255, 0.08)',
          scaleMargins: { top: 0.1, bottom: 0.12 },
        },
        timeScale: {
          borderColor: 'rgba(255, 255, 255, 0.08)',
          timeVisible: true,
          secondsVisible: false,
          rightOffset: 8,
          barSpacing: 9,
        },
        width: el.clientWidth,
        height: el.clientHeight || 460,
      });

      const candleSeries = chart.addSeries(CandlestickSeries, {
        upColor: '#10B981',
        downColor: '#EF4444',
        borderUpColor: '#10B981',
        borderDownColor: '#EF4444',
        wickUpColor: '#10B981',
        wickDownColor: '#EF4444',
      });

      const ema9 = chart.addSeries(LineSeries, {
        color: '#D4AF37',
        lineWidth: 1,
        priceLineVisible: false,
        lastValueVisible: false,
      });
      const ema21 = chart.addSeries(LineSeries, {
        color: '#38BDF8',
        lineWidth: 1,
        priceLineVisible: false,
        lastValueVisible: false,
      });
      const ema50 = chart.addSeries(LineSeries, {
        color: '#A78BFA',
        lineWidth: 2,
        priceLineVisible: false,
        lastValueVisible: false,
      });

      const bbUpper = chart.addSeries(LineSeries, {
        color: 'rgba(148, 163, 184, 0.45)',
        lineWidth: 1,
        lineStyle: LineStyle.Dotted,
        priceLineVisible: false,
        lastValueVisible: false,
      });
      const bbLower = chart.addSeries(LineSeries, {
        color: 'rgba(148, 163, 184, 0.45)',
        lineWidth: 1,
        lineStyle: LineStyle.Dotted,
        priceLineVisible: false,
        lastValueVisible: false,
      });

      chart.subscribeCrosshairMove((param) => {
        if (!param.time) {
          setHoveredCandle(null);
          return;
        }
        const bar = param.seriesData.get(candleSeries) as
          | { open: number; high: number; low: number; close: number }
          | undefined;
        if (bar) {
          setHoveredCandle({
            open: bar.open,
            high: bar.high,
            low: bar.low,
            close: bar.close,
          });
        }
      });

      chartRef.current = chart;
      candleSeriesRef.current = candleSeries;
      ema9SeriesRef.current = ema9;
      ema21SeriesRef.current = ema21;
      ema50SeriesRef.current = ema50;
      bbUpperRef.current = bbUpper;
      bbLowerRef.current = bbLower;

      const resizeObserver = new ResizeObserver((entries) => {
        for (const entry of entries) {
          const { width, height } = entry.contentRect;
          if (width > 0 && height > 0) {
            chart.applyOptions({ width, height });
          }
        }
      });
      resizeObserver.observe(el);

      return () => {
        resizeObserver.disconnect();
        chart.remove();
        chartRef.current = null;
      };
    }, []);

    // Update series data when snapshot updates
    useEffect(() => {
      if (!snapshot || !candleSeriesRef.current) return;

      const candleData = snapshot.candles.map((c) => ({
        time: c.time as UTCTimestamp,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }));
      candleSeriesRef.current.setData(candleData);

      if (showEmas) {
        ema9SeriesRef.current?.setData(
          snapshot.ema9Series.map((p) => ({ time: p.time as UTCTimestamp, value: p.value }))
        );
        ema21SeriesRef.current?.setData(
          snapshot.ema21Series.map((p) => ({ time: p.time as UTCTimestamp, value: p.value }))
        );
        ema50SeriesRef.current?.setData(
          snapshot.ema50Series.map((p) => ({ time: p.time as UTCTimestamp, value: p.value }))
        );
      } else {
        ema9SeriesRef.current?.setData([]);
        ema21SeriesRef.current?.setData([]);
        ema50SeriesRef.current?.setData([]);
      }

      if (showBollinger) {
        bbUpperRef.current?.setData(
          snapshot.bbUpperSeries.map((p) => ({ time: p.time as UTCTimestamp, value: p.value }))
        );
        bbLowerRef.current?.setData(
          snapshot.bbLowerSeries.map((p) => ({ time: p.time as UTCTimestamp, value: p.value }))
        );
      } else {
        bbUpperRef.current?.setData([]);
        bbLowerRef.current?.setData([]);
      }

      if (!hasFittedRef.current && candleData.length > 0) {
        const visibleCount = Math.min(85, candleData.length);
        chartRef.current?.timeScale().setVisibleLogicalRange({
          from: candleData.length - visibleCount,
          to: candleData.length + 6,
        });
        hasFittedRef.current = true;
      }
    }, [snapshot, showEmas, showBollinger]);

    // Update AI & Active Position horizontal price lines
    useEffect(() => {
      const series = candleSeriesRef.current;
      if (!series) return;

      for (const line of priceLinesRef.current) {
        series.removePriceLine(line);
      }
      priceLinesRef.current = [];

      if (showAiLevels && latestAnalysis && latestAnalysis.signal !== 'HOLD') {
        priceLinesRef.current.push(
          series.createPriceLine({
            price: latestAnalysis.entryPrice,
            color: '#D4AF37',
            lineWidth: 1,
            lineStyle: LineStyle.Dashed,
            axisLabelVisible: true,
            title: `AI ${latestAnalysis.signal}`,
          }),
          series.createPriceLine({
            price: latestAnalysis.stopLoss,
            color: '#EF4444',
            lineWidth: 1,
            lineStyle: LineStyle.Dotted,
            axisLabelVisible: true,
            title: 'AI SL',
          }),
          series.createPriceLine({
            price: latestAnalysis.takeProfit1,
            color: '#10B981',
            lineWidth: 1,
            lineStyle: LineStyle.Dotted,
            axisLabelVisible: true,
            title: 'AI TP1',
          })
        );
      }

      openPositions.forEach((pos, idx) => {
        const labelIdx = openPositions.length > 1 ? ` #${idx + 1}` : '';
        priceLinesRef.current.push(
          series.createPriceLine({
            price: pos.entryPrice,
            color: pos.side === 'BUY' ? '#10B981' : '#EF4444',
            lineWidth: 2,
            lineStyle: LineStyle.Solid,
            axisLabelVisible: true,
            title: `${pos.side}${labelIdx} (${pos.lots})`,
          }),
          series.createPriceLine({
            price: pos.stopLoss,
            color: '#F87171',
            lineWidth: 1,
            lineStyle: LineStyle.LargeDashed,
            axisLabelVisible: true,
            title: `SL${labelIdx}`,
          }),
          series.createPriceLine({
            price: pos.takeProfit,
            color: '#34D399',
            lineWidth: 1,
            lineStyle: LineStyle.LargeDashed,
            axisLabelVisible: true,
            title: `TP${labelIdx}`,
          })
        );
      });
    }, [latestAnalysis, openPositions, showAiLevels]);

    const latestBar = snapshot?.candles[snapshot.candles.length - 1];
    const displayBar = hoveredCandle || latestBar;

    return (
      <div className="flex flex-col bg-[#0B0E14] border border-white/[0.08] rounded-lg overflow-hidden">
        {/* Chart Toolbar */}
        <div className="px-4 py-2.5 border-b border-white/[0.08] bg-[#111620] flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4 text-xs font-mono tabular-nums">
            <span className="font-sans font-semibold text-[#F8FAFC]">
              Chart XAU/USD M5
            </span>
            {displayBar && (
              <div className="flex items-center gap-3 text-[#94A3B8]">
                <span>
                  O <strong className="text-[#E6EDF3] font-medium">{displayBar.open.toFixed(2)}</strong>
                </span>
                <span>
                  H <strong className="text-[#E6EDF3] font-medium">{displayBar.high.toFixed(2)}</strong>
                </span>
                <span>
                  L <strong className="text-[#E6EDF3] font-medium">{displayBar.low.toFixed(2)}</strong>
                </span>
                <span>
                  C{' '}
                  <strong
                    className={`font-medium ${
                      displayBar.close >= displayBar.open ? 'text-[#10B981]' : 'text-[#EF4444]'
                    }`}
                  >
                    {displayBar.close.toFixed(2)}
                  </strong>
                </span>
              </div>
            )}
            {showEmas && snapshot && (
              <div className="hidden md:flex items-center gap-3 text-[11px]">
                <span className="text-[#D4AF37]">
                  EMA9 {snapshot.indicators.ema9?.toFixed(2) ?? '--'}
                </span>
                <span className="text-[#38BDF8]">
                  EMA21 {snapshot.indicators.ema21?.toFixed(2) ?? '--'}
                </span>
                <span className="text-[#A78BFA]">
                  EMA50 {snapshot.indicators.ema50?.toFixed(2) ?? '--'}
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setShowEmas((v) => !v)}
              className={`px-2.5 py-1 text-xs font-medium rounded border transition-colors whitespace-nowrap ${
                showEmas
                  ? 'bg-[#1E293B] text-[#F8FAFC] border-white/20'
                  : 'bg-transparent text-[#94A3B8] border-white/[0.08] hover:text-[#E6EDF3]'
              }`}
            >
              EMA 9/21/50
            </button>
            <button
              type="button"
              onClick={() => setShowBollinger((v) => !v)}
              className={`px-2.5 py-1 text-xs font-medium rounded border transition-colors whitespace-nowrap ${
                showBollinger
                  ? 'bg-[#1E293B] text-[#F8FAFC] border-white/20'
                  : 'bg-transparent text-[#94A3B8] border-white/[0.08] hover:text-[#E6EDF3]'
              }`}
            >
              Bollinger
            </button>
            <button
              type="button"
              onClick={() => setShowAiLevels((v) => !v)}
              className={`px-2.5 py-1 text-xs font-medium rounded border transition-colors whitespace-nowrap ${
                showAiLevels
                  ? 'bg-[#1E293B] text-[#D4AF37] border-[#D4AF37]/40'
                  : 'bg-transparent text-[#94A3B8] border-white/[0.08] hover:text-[#E6EDF3]'
              }`}
            >
              Level AI
            </button>
            <button
              type="button"
              onClick={() => {
                if (!snapshot?.candles.length || !chartRef.current) return;
                const len = snapshot.candles.length;
                chartRef.current.timeScale().setVisibleLogicalRange({
                  from: Math.max(0, len - 85),
                  to: len + 6,
                });
              }}
              className="px-2.5 py-1 text-xs font-medium rounded border border-white/[0.08] text-[#94A3B8] hover:text-[#E6EDF3] transition-colors whitespace-nowrap"
            >
              Reset Zoom
            </button>
          </div>
        </div>

        {/* Canvas Viewport */}
        <div className="relative w-full h-[340px] sm:h-[430px] lg:h-[500px] bg-[#0B0E14]">
          <div ref={containerRef} className="w-full h-full" />

          {loading && !snapshot && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#0B0E14]/90">
              <div className="text-center space-y-2">
                <div className="w-6 h-6 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-xs text-[#94A3B8]">Memuat candlestick M5 XAU/USD real-time...</p>
              </div>
            </div>
          )}

          {error && !snapshot && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#0B0E14]/95 p-6">
              <div className="max-w-sm text-center space-y-3">
                <p className="text-sm font-medium text-[#EF4444]">Koneksi Feed Pasar Terputus</p>
                <p className="text-xs text-[#94A3B8]">{error}</p>
                <button
                  type="button"
                  onClick={onRetry}
                  className="px-4 py-2 text-xs font-semibold rounded-md bg-[#1E293B] text-[#F8FAFC] hover:bg-[#334155] transition-colors"
                >
                  Coba Hubungkan Ulang
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
);

CandlestickChart.displayName = 'CandlestickChart';
