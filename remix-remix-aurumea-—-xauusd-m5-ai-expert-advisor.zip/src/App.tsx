import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { TopBar, type ActiveTab } from './components/TopBar.tsx';
import { MarketStrip } from './components/MarketStrip.tsx';
import {
  CandlestickChart,
  type CandlestickChartHandle,
} from './components/CandlestickChart.tsx';
import { EaSignalPanel } from './components/EaSignalPanel.tsx';
import { PositionsDrawer } from './components/PositionsDrawer.tsx';
import { EaSettingsView } from './components/EaSettingsView.tsx';
import { HistoryAnalyticsView } from './components/HistoryAnalyticsView.tsx';
import { BarChart3, CandlestickChart as CandlestickIcon, Cpu, SlidersHorizontal } from 'lucide-react';
import { Mql5BridgeView } from './components/Mql5BridgeView.tsx';
import { OfflineIndicator } from './components/OfflineIndicator.tsx';
import { RiskToastStack } from './components/RiskToastStack.tsx';
import type {
  ClosedTrade,
  EaAnalysisResult,
  EaConfig,
  MarketSnapshot,
  Mt5BridgeStatus,
  OpenPosition,
  RiskNotification,
} from './types/trading.ts';
import { calculateXauLotSize, calculateXauPnl } from './utils/indicators.ts';

const STORAGE_KEYS = {
  CONFIG: 'aurumea_v1_config',
  BALANCE: 'aurumea_v1_balance',
  POSITIONS: 'aurumea_v1_positions',
  HISTORY: 'aurumea_v1_history',
  LOGS: 'aurumea_v1_logs',
};

const DEFAULT_CONFIG: EaConfig = {
  autoAnalyze: false,
  analyzeCadence: '30S',
  autoExecute: false,
  minConfidence: 76,
  lotMode: 'RISK_PERCENT',
  riskPercent: 1.0,
  fixedLot: 0.05,
  maxOpenPositions: 2,
  maxDailyLossPercent: 5.0,
  useTrailingStop: true,
  trailingAtrMultiplier: 0.9,
  useBreakeven: true,
  breakevenTriggerUsd: 1.2,
  fullAiControl: true,
  strategyFocus: 'SCALPING_EMA',
  initialBalance: 10000,
};

const INITIAL_MT5_STATUS: Mt5BridgeStatus = {
  configured: false,
  connected: false,
  profile: null,
  lastHeartbeatAt: null,
  liveAccount: null,
  pendingCommandsCount: 0,
};

function readStoredJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('terminal');
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const [loadingFeed, setLoadingFeed] = useState(true);
  const [feedError, setFeedError] = useState<string | null>(null);
  const [streamConnected, setStreamConnected] = useState(false);

  const [config, setConfig] = useState<EaConfig>(() =>
    readStoredJson<EaConfig>(STORAGE_KEYS.CONFIG, DEFAULT_CONFIG)
  );
  const [simBalance, setSimBalance] = useState<number>(() =>
    readStoredJson<number>(STORAGE_KEYS.BALANCE, DEFAULT_CONFIG.initialBalance)
  );
  const [simPositions, setSimPositions] = useState<OpenPosition[]>(() =>
    readStoredJson<OpenPosition[]>(STORAGE_KEYS.POSITIONS, [])
  );
  const [closedTrades, setClosedTrades] = useState<ClosedTrade[]>(() =>
    readStoredJson<ClosedTrade[]>(STORAGE_KEYS.HISTORY, [])
  );
  const [analysisLogs, setAnalysisLogs] = useState<EaAnalysisResult[]>(() =>
    readStoredJson<EaAnalysisResult[]>(STORAGE_KEYS.LOGS, [])
  );

  const [mt5Status, setMt5Status] = useState<Mt5BridgeStatus>(INITIAL_MT5_STATUS);
  const [riskNotifications, setRiskNotifications] = useState<RiskNotification[]>([]);

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [autoCountdownSec, setAutoCountdownSec] = useState<number | null>(null);

  const chartRef = useRef<CandlestickChartHandle | null>(null);
  const lastAnalyzedCandleRef = useRef<number | null>(null);
  const isAnalyzingRef = useRef(false);
  const mt5StatusRef = useRef(mt5Status);
  const configRef = useRef(config);
  const snapshotRef = useRef(snapshot);

  // Active balance & positions come from real MT5 account when connected, otherwise local sim
  const isMt5Live = Boolean(mt5Status.connected && mt5Status.liveAccount);
  const activeBalance = isMt5Live ? mt5Status.liveAccount!.balance : simBalance;

  const activePositions: OpenPosition[] = useMemo(() => {
    if (isMt5Live && mt5Status.liveAccount) {
      return mt5Status.liveAccount.positions.map((p) => ({
        id: `mt5_${p.ticket}`,
        mt5Ticket: p.ticket,
        side: p.side,
        lots: p.lots,
        entryPrice: p.openPrice,
        stopLoss: p.sl,
        takeProfit: p.tp,
        openedAt: p.openTime || Date.now(),
        source: 'MT5_LIVE',
        highestFavorablePrice: p.openPrice,
        trailingActivated: false,
      }));
    }
    return simPositions;
  }, [isMt5Live, mt5Status.liveAccount, simPositions]);

  const activePositionsRef = useRef(activePositions);
  const activeBalanceRef = useRef(activeBalance);
  activePositionsRef.current = activePositions;
  activeBalanceRef.current = activeBalance;
  mt5StatusRef.current = mt5Status;
  configRef.current = config;
  snapshotRef.current = snapshot;

  const pushRiskNotification = useCallback(
    (item: Omit<RiskNotification, 'id' | 'timestamp'>) => {
      const id = `risk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      const entry: RiskNotification = { ...item, id, timestamp: Date.now() };
      setRiskNotifications((prev) => [entry, ...prev].slice(0, 4));
      setTimeout(() => {
        setRiskNotifications((prev) => prev.filter((n) => n.id !== id));
      }, 9000);
    },
    []
  );

  // Persist local simulation & config state
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
  }, [config]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BALANCE, JSON.stringify(simBalance));
  }, [simBalance]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.POSITIONS, JSON.stringify(simPositions));
  }, [simPositions]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(closedTrades));
  }, [closedTrades]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(analysisLogs.slice(0, 50)));
  }, [analysisLogs]);

  // Poll MT5 bridge status
  const refreshMt5Status = useCallback(async () => {
    try {
      const res = await fetch('/api/mt5/status');
      if (!res.ok) return;
      const data = (await res.json()) as Mt5BridgeStatus;
      setMt5Status(data);
    } catch {
      // Ignore transient poll error
    }
  }, []);

  useEffect(() => {
    void refreshMt5Status();
    const interval = setInterval(() => {
      void refreshMt5Status();
    }, 3000);
    return () => clearInterval(interval);
  }, [refreshMt5Status]);

  // Fetch initial candles snapshot + open real-time SSE market stream
  const connectStream = useCallback(() => {
    setLoadingFeed(true);
    setFeedError(null);

    fetch('/api/market/candles')
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Gagal memuat data pasar.');
        setSnapshot(data as MarketSnapshot);
        setLoadingFeed(false);
      })
      .catch((err: unknown) => {
        setFeedError(err instanceof Error ? err.message : 'Feed error');
        setLoadingFeed(false);
      });

    const es = new EventSource('/api/market/stream');
    es.addEventListener('tick', (ev) => {
      try {
        const parsed = JSON.parse((ev as MessageEvent).data) as MarketSnapshot;
        setSnapshot(parsed);
        setStreamConnected(true);
        setLoadingFeed(false);
        setFeedError(null);
      } catch {
        // Ignore malformed event
      }
    });
    es.addEventListener('feed_error', (ev) => {
      try {
        const parsed = JSON.parse((ev as MessageEvent).data) as { error?: string };
        setFeedError(parsed.error || 'Koneksi feed terganggu.');
      } catch {
        // Ignore
      }
      setStreamConnected(false);
    });
    es.onerror = () => {
      setStreamConnected(false);
    };

    return () => {
      es.close();
    };
  }, []);

  useEffect(() => {
    const cleanup = connectStream();
    return cleanup;
  }, [connectStream]);

  // Smooth 1-second candle countdown tick locally
  useEffect(() => {
    const timer = setInterval(() => {
      setSnapshot((prev) => {
        if (!prev) return prev;
        const nowSec = Math.floor(Date.now() / 1000);
        const boundary = Math.floor(nowSec / 300) * 300;
        const closeIn = Math.max(0, boundary + 300 - nowSec);
        if (prev.quote.candleCloseInSec === closeIn) return prev;
        return {
          ...prev,
          quote: {
            ...prev.quote,
            candleCloseInSec: closeIn,
          },
        };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Live Simulation Position Monitor (only runs for web sim positions; MT5 Live handles SL/TP on broker)
  useEffect(() => {
    if (isMt5Live || !snapshot || simPositions.length === 0) return;
    const { bid, ask } = snapshot.quote;
    const atr = snapshot.indicators.atr14 ?? 2.5;
    const cfg = configRef.current;

    const remaining: OpenPosition[] = [];
    const newlyClosed: ClosedTrade[] = [];
    let realizedDelta = 0;

    for (const pos of simPositions) {
      const exitPrice = pos.side === 'BUY' ? bid : ask;
      let hitReason: ClosedTrade['closeReason'] | null = null;
      let closePrice = exitPrice;

      if (pos.side === 'BUY') {
        if (exitPrice <= pos.stopLoss) {
          hitReason = pos.trailingActivated ? 'Trailing SL' : 'SL Hit';
          closePrice = pos.stopLoss;
        } else if (exitPrice >= pos.takeProfit) {
          hitReason = 'TP Hit';
          closePrice = pos.takeProfit;
        }
      } else {
        if (exitPrice >= pos.stopLoss) {
          hitReason = pos.trailingActivated ? 'Trailing SL' : 'SL Hit';
          closePrice = pos.stopLoss;
        } else if (exitPrice <= pos.takeProfit) {
          hitReason = 'TP Hit';
          closePrice = pos.takeProfit;
        }
      }

      if (hitReason) {
        const pnlUsd = calculateXauPnl(pos.side, pos.lots, pos.entryPrice, closePrice);
        const points =
          pos.side === 'BUY' ? closePrice - pos.entryPrice : pos.entryPrice - closePrice;
        realizedDelta += pnlUsd;
        newlyClosed.push({
          id: pos.id,
          side: pos.side,
          lots: pos.lots,
          entryPrice: pos.entryPrice,
          closePrice: Number(closePrice.toFixed(2)),
          stopLoss: pos.stopLoss,
          takeProfit: pos.takeProfit,
          openedAt: pos.openedAt,
          closedAt: Date.now(),
          pnlUsd,
          points: Number(points.toFixed(2)),
          closeReason: hitReason,
          source: pos.source,
          setupPattern: pos.setupPattern,
        });
      } else {
        let updatedPos = pos;
        const useBe = cfg.useBreakeven ?? true;
        const beTrig = cfg.breakevenTriggerUsd ?? 1.2;

        if (useBe) {
          if (pos.side === 'BUY') {
            const best = Math.max(pos.highestFavorablePrice, exitPrice);
            const beSl = Number((pos.entryPrice + 0.2).toFixed(2));
            if (best - pos.entryPrice >= beTrig && beSl > updatedPos.stopLoss && beSl < exitPrice) {
              updatedPos = {
                ...updatedPos,
                highestFavorablePrice: best,
                stopLoss: beSl,
                trailingActivated: true,
              };
            }
          } else {
            const best = Math.min(pos.highestFavorablePrice, exitPrice);
            const beSl = Number((pos.entryPrice - 0.2).toFixed(2));
            if (pos.entryPrice - best >= beTrig && beSl < updatedPos.stopLoss && beSl > exitPrice) {
              updatedPos = {
                ...updatedPos,
                highestFavorablePrice: best,
                stopLoss: beSl,
                trailingActivated: true,
              };
            }
          }
        }

        if (cfg.useTrailingStop) {
          const trailDist = atr * cfg.trailingAtrMultiplier;
          if (pos.side === 'BUY') {
            const best = Math.max(updatedPos.highestFavorablePrice, exitPrice);
            const candidateSl = Number((best - trailDist).toFixed(2));
            if (best - pos.entryPrice >= trailDist && candidateSl > updatedPos.stopLoss) {
              updatedPos = {
                ...updatedPos,
                highestFavorablePrice: best,
                stopLoss: candidateSl,
                trailingActivated: true,
              };
            } else if (best > updatedPos.highestFavorablePrice) {
              updatedPos = { ...updatedPos, highestFavorablePrice: best };
            }
          } else {
            const best = Math.min(updatedPos.highestFavorablePrice, exitPrice);
            const candidateSl = Number((best + trailDist).toFixed(2));
            if (pos.entryPrice - best >= trailDist && candidateSl < updatedPos.stopLoss) {
              updatedPos = {
                ...updatedPos,
                highestFavorablePrice: best,
                stopLoss: candidateSl,
                trailingActivated: true,
              };
            } else if (best < updatedPos.highestFavorablePrice) {
              updatedPos = { ...updatedPos, highestFavorablePrice: best };
            }
          }
        }
        remaining.push(updatedPos);
      }
    }

    if (newlyClosed.length > 0) {
      setSimPositions(remaining);
      setClosedTrades((prev) => [...newlyClosed, ...prev]);
      setSimBalance((prev) => Number((prev + realizedDelta).toFixed(2)));
    } else if (remaining.some((p, i) => p !== simPositions[i])) {
      setSimPositions(remaining);
    }
  }, [isMt5Live, snapshot, simPositions]);

  // Compute current active risk exposure across open positions
  const exposureMetrics = useMemo(() => {
    const usd = activePositions.reduce((acc, pos) => {
      const dist = pos.stopLoss > 0 ? Math.abs(pos.entryPrice - pos.stopLoss) : 0;
      return acc + dist * pos.lots * 100;
    }, 0);
    const pct = activeBalance > 0 ? (usd / activeBalance) * 100 : 0;
    return {
      usd: Number(usd.toFixed(2)),
      pct: Number(pct.toFixed(2)),
    };
  }, [activePositions, activeBalance]);

  const openOrder = useCallback(
    async (params: {
      side: 'BUY' | 'SELL';
      stopLoss: number;
      takeProfit: number;
      source: OpenPosition['source'];
      confidence?: number;
      setupPattern?: string;
    }) => {
      const snap = snapshotRef.current;
      if (!snap) return;

      const cfg = configRef.current;
      const curBalance = activeBalanceRef.current;
      const entry = params.side === 'BUY' ? snap.quote.ask : snap.quote.bid;
      const sl = Number(params.stopLoss.toFixed(2));
      const tp = Number(params.takeProfit.toFixed(2));

      const lots =
        cfg.lotMode === 'FIXED_LOT'
          ? cfg.fixedLot
          : calculateXauLotSize(curBalance, cfg.riskPercent, entry, sl);

      const tradeRiskUsd = Number((Math.abs(entry - sl) * lots * 100).toFixed(2));
      const tradeRiskPct =
        curBalance > 0 ? Number(((tradeRiskUsd / curBalance) * 100).toFixed(2)) : 0;
      const currentExposureUsd = activePositionsRef.current.reduce(
        (acc, p) => acc + Math.abs(p.entryPrice - p.stopLoss) * p.lots * 100,
        0
      );
      const nextTotalExposurePct =
        curBalance > 0
          ? Number((((currentExposureUsd + tradeRiskUsd) / curBalance) * 100).toFixed(2))
          : 0;

      const level: RiskNotification['level'] =
        nextTotalExposurePct >= cfg.maxDailyLossPercent
          ? 'CRITICAL'
          : tradeRiskPct > cfg.riskPercent * 1.35 || nextTotalExposurePct >= 3
          ? 'WARNING'
          : 'INFO';

      const liveMt5 = mt5StatusRef.current;
      if (liveMt5.connected) {
        try {
          const res = await fetch('/api/mt5/order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: params.side,
              lots,
              sl,
              tp,
              comment: params.setupPattern || 'AurumEA M5',
            }),
          });
          const data = (await res.json()) as { error?: string };
          if (!res.ok) {
            throw new Error(data.error || 'Gagal mengirim perintah order ke MT5.');
          }
          pushRiskNotification({
            level,
            title: `Order Real MT5 Dikirim (${params.side} ${lots.toFixed(2)} Lot)`,
            message: `Perintah ${params.side} XAU/USD @ ${entry.toFixed(2)} dikirim ke MT5 #${liveMt5.profile?.login} (${liveMt5.profile?.server}).`,
            tradeRiskPercent: tradeRiskPct,
            tradeRiskUsd,
            totalExposurePercent: nextTotalExposurePct,
          });
        } catch (err: unknown) {
          pushRiskNotification({
            level: 'CRITICAL',
            title: 'Eksekusi MT5 Gagal',
            message: err instanceof Error ? err.message : 'Gagal mengirim order ke MT5.',
            tradeRiskPercent: tradeRiskPct,
            tradeRiskUsd,
            totalExposurePercent: nextTotalExposurePct,
          });
        }
        return;
      }

      // Simulation mode execution
      const newPos: OpenPosition = {
        id: `pos_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        side: params.side,
        lots,
        entryPrice: Number(entry.toFixed(2)),
        stopLoss: sl,
        takeProfit: tp,
        openedAt: Date.now(),
        source: params.source,
        confidence: params.confidence,
        setupPattern: params.setupPattern,
        highestFavorablePrice: Number(entry.toFixed(2)),
        trailingActivated: false,
      };

      setSimPositions((prev) => [newPos, ...prev]);

      pushRiskNotification({
        level,
        title: `Notifikasi Risiko Order (${params.side} ${lots.toFixed(2)} Lot)`,
        message: `Posisi simulasi ${params.side} XAU/USD dibuka @ ${entry.toFixed(2)} (SL ${sl.toFixed(2)}).`,
        tradeRiskPercent: tradeRiskPct,
        tradeRiskUsd,
        totalExposurePercent: nextTotalExposurePct,
      });
    },
    [pushRiskNotification]
  );

  // Run Gemini AI Chart Analysis
  const runGeminiAnalysis = useCallback(
    async (triggeredByAuto: boolean) => {
      if (isAnalyzingRef.current) return;
      isAnalyzingRef.current = true;
      setIsAnalyzing(true);
      setAnalysisError(null);

      try {
        const chartImageBase64 = chartRef.current?.captureChartImage() || undefined;
        const cfg = configRef.current;
        const positions = activePositionsRef.current;
        const curBalance = activeBalanceRef.current;

        const openSummary =
          positions.length === 0
            ? 'Tidak ada posisi aktif'
            : positions
                .map((p) => `${p.side} ${p.lots} lot @ ${p.entryPrice}`)
                .join(', ');

        const res = await fetch('/api/ea/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chartImageBase64,
            strategyFocus: cfg.strategyFocus,
            riskPercent: cfg.riskPercent,
            accountBalance: curBalance,
            openPositionsCount: positions.length,
            openPositionsSummary: openSummary,
            fullAiControl: cfg.fullAiControl ?? true,
          }),
        });

        const data = (await res.json()) as {
          analysis?: EaAnalysisResult;
          snapshot?: MarketSnapshot;
          error?: string;
        };

        if (!res.ok || !data.analysis) {
          throw new Error(data.error || 'Gagal menjalankan analisa Gemini.');
        }

        if (data.snapshot) {
          setSnapshot(data.snapshot);
        }

        const analysis = data.analysis;
        lastAnalyzedCandleRef.current = analysis.candleTime;
        setAnalysisLogs((prev) => [analysis, ...prev].slice(0, 50));

        // Notify user of calculated % risk when Gemini identifies an actionable setup
        if (analysis.signal !== 'HOLD') {
          const calcLots =
            cfg.lotMode === 'FIXED_LOT'
              ? cfg.fixedLot
              : calculateXauLotSize(
                  curBalance,
                  cfg.riskPercent,
                  analysis.entryPrice,
                  analysis.stopLoss
                );
          const signalRiskUsd = Number(
            (Math.abs(analysis.entryPrice - analysis.stopLoss) * calcLots * 100).toFixed(2)
          );
          const signalRiskPct =
            curBalance > 0 ? Number(((signalRiskUsd / curBalance) * 100).toFixed(2)) : 0;
          const activeRiskUsd = positions.reduce(
            (acc, p) => acc + Math.abs(p.entryPrice - p.stopLoss) * p.lots * 100,
            0
          );
          const activeRiskPct =
            curBalance > 0 ? Number(((activeRiskUsd / curBalance) * 100).toFixed(2)) : 0;

          pushRiskNotification({
            level:
              activeRiskPct + signalRiskPct >= cfg.maxDailyLossPercent ? 'WARNING' : 'INFO',
            title: `Sinyal Gemini ${analysis.signal} (${analysis.confidence}%)`,
            message: `Setup ${analysis.setupPattern}. Rekomendasi ${calcLots.toFixed(
              2
            )} lot dengan risiko ${signalRiskPct.toFixed(2)}% ($${signalRiskUsd.toFixed(2)}).`,
            tradeRiskPercent: signalRiskPct,
            tradeRiskUsd: signalRiskUsd,
            totalExposurePercent: activeRiskPct,
          });
        }

        // Auto-Execution Guardrail Check (100% AI Judge authority when fullAiControl is enabled)
        const isFullAi = cfg.fullAiControl ?? true;
        const passesConfidence = isFullAi || analysis.confidence >= cfg.minConfidence;

        if (
          triggeredByAuto &&
          cfg.autoExecute &&
          analysis.signal !== 'HOLD' &&
          passesConfidence &&
          positions.length < cfg.maxOpenPositions
        ) {
          const todayStart = new Date();
          todayStart.setHours(0, 0, 0, 0);
          const dailyRealized = closedTrades
            .filter((t) => t.closedAt >= todayStart.getTime())
            .reduce((acc, t) => acc + t.pnlUsd, 0);
          const maxLossUsd = (cfg.initialBalance * cfg.maxDailyLossPercent) / 100;

          if (dailyRealized > -maxLossUsd) {
            await openOrder({
              side: analysis.signal,
              stopLoss: analysis.stopLoss,
              takeProfit: analysis.takeProfit1,
              source: 'AI_AUTO',
              confidence: analysis.confidence,
              setupPattern: analysis.setupPattern,
            });
          }
        }
      } catch (err: unknown) {
        setAnalysisError(
          err instanceof Error ? err.message : 'Terjadi kesalahan saat memanggil endpoint Gemini.'
        );
      } finally {
        isAnalyzingRef.current = false;
        setIsAnalyzing(false);
      }
    },
    [closedTrades, openOrder, pushRiskNotification]
  );

  // Auto-Analyze Scheduler
  useEffect(() => {
    if (!config.autoAnalyze) {
      setAutoCountdownSec(null);
      return;
    }

    if (config.analyzeCadence === 'CANDLE_CLOSE') {
      const interval = setInterval(() => {
        const snap = snapshotRef.current;
        if (!snap || snap.candles.length === 0) return;
        const latestCandleTime = snap.candles[snap.candles.length - 1].time;
        setAutoCountdownSec(snap.quote.candleCloseInSec);

        if (
          lastAnalyzedCandleRef.current !== null &&
          latestCandleTime > lastAnalyzedCandleRef.current &&
          !isAnalyzingRef.current
        ) {
          void runGeminiAnalysis(true);
        } else if (lastAnalyzedCandleRef.current === null && !isAnalyzingRef.current) {
          void runGeminiAnalysis(true);
        }
      }, 1000);
      return () => clearInterval(interval);
    }

    const cadenceSec =
      config.analyzeCadence === '30S' ? 30 : config.analyzeCadence === '60S' ? 60 : 180;
    let remaining = 3;
    setAutoCountdownSec(remaining);

    const interval = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0) {
        remaining = cadenceSec;
        if (!isAnalyzingRef.current) {
          void runGeminiAnalysis(true);
        }
      }
      setAutoCountdownSec(remaining);
    }, 1000);

    return () => clearInterval(interval);
  }, [config.autoAnalyze, config.analyzeCadence, runGeminiAnalysis]);

  const handleClosePosition = useCallback(async (id: string) => {
    const snap = snapshotRef.current;
    if (!snap) return;

    if (mt5StatusRef.current.connected && id.startsWith('mt5_')) {
      const ticket = Number(id.replace('mt5_', ''));
      await fetch('/api/mt5/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'CLOSE', ticket }),
      });
      return;
    }

    setSimPositions((prev) => {
      const target = prev.find((p) => p.id === id);
      if (!target) return prev;
      const closePrice = target.side === 'BUY' ? snap.quote.bid : snap.quote.ask;
      const pnlUsd = calculateXauPnl(target.side, target.lots, target.entryPrice, closePrice);
      const points =
        target.side === 'BUY' ? closePrice - target.entryPrice : target.entryPrice - closePrice;

      const closed: ClosedTrade = {
        id: target.id,
        side: target.side,
        lots: target.lots,
        entryPrice: target.entryPrice,
        closePrice: Number(closePrice.toFixed(2)),
        stopLoss: target.stopLoss,
        takeProfit: target.takeProfit,
        openedAt: target.openedAt,
        closedAt: Date.now(),
        pnlUsd,
        points: Number(points.toFixed(2)),
        closeReason: 'Manual Close',
        source: target.source,
        setupPattern: target.setupPattern,
      };

      setClosedTrades((hist) => [closed, ...hist]);
      setSimBalance((b) => Number((b + pnlUsd).toFixed(2)));
      return prev.filter((p) => p.id !== id);
    });
  }, []);

  const handleCloseAll = useCallback(async () => {
    if (mt5StatusRef.current.connected) {
      await fetch('/api/mt5/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'CLOSE_ALL' }),
      });
      return;
    }
    const ids = activePositionsRef.current.map((p) => p.id);
    for (const id of ids) {
      await handleClosePosition(id);
    }
  }, [handleClosePosition]);

  const handleQuickMarketOrder = useCallback(
    (side: 'BUY' | 'SELL') => {
      const snap = snapshotRef.current;
      if (!snap) return;
      const cfg = configRef.current;
      const isScalp = cfg.strategyFocus === 'SCALPING_EMA' || cfg.strategyFocus === 'ULTRA_SCALP';
      const atr = snap.indicators.atr14 ?? 2.5;
      const entry = side === 'BUY' ? snap.quote.ask : snap.quote.bid;
      const slDist = Number((atr * (isScalp ? 1.0 : 1.5)).toFixed(2));
      const tpDist = Number((atr * (isScalp ? 1.35 : 2.5)).toFixed(2));

      void openOrder({
        side,
        stopLoss: side === 'BUY' ? entry - slDist : entry + slDist,
        takeProfit: side === 'BUY' ? entry + tpDist : entry - tpDist,
        source: 'MARKET_MANUAL',
        setupPattern: isScalp ? 'Quick Scalp Market' : 'Market Order',
      });
    },
    [openOrder]
  );

  const latestAnalysis = analysisLogs[0] || null;

  const handleExecuteAiSignal = useCallback(() => {
    if (!latestAnalysis || latestAnalysis.signal === 'HOLD') return;
    void openOrder({
      side: latestAnalysis.signal,
      stopLoss: latestAnalysis.stopLoss,
      takeProfit: latestAnalysis.takeProfit1,
      source: 'AI_MANUAL',
      confidence: latestAnalysis.confidence,
      setupPattern: latestAnalysis.setupPattern,
    });
  }, [latestAnalysis, openOrder]);

  const floatingPnl = useMemo(() => {
    if (isMt5Live && mt5Status.liveAccount) {
      const total = mt5Status.liveAccount.positions.reduce((acc, p) => acc + p.profit, 0);
      return Number(total.toFixed(2));
    }
    if (!snapshot || activePositions.length === 0) return 0;
    const total = activePositions.reduce((acc, pos) => {
      const mark = pos.side === 'BUY' ? snapshot.quote.bid : snapshot.quote.ask;
      return acc + calculateXauPnl(pos.side, pos.lots, pos.entryPrice, mark);
    }, 0);
    return Number(total.toFixed(2));
  }, [isMt5Live, mt5Status.liveAccount, snapshot, activePositions]);

  const equity =
    isMt5Live && mt5Status.liveAccount
      ? mt5Status.liveAccount.equity
      : Number((activeBalance + floatingPnl).toFixed(2));

  const handleResetAccount = () => {
    setSimPositions([]);
    setClosedTrades([]);
    setAnalysisLogs([]);
    setSimBalance(config.initialBalance);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0B0E14] text-[#E6EDF3]">
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onAnalyzeNow={() => void runGeminiAnalysis(false)}
        isAnalyzing={isAnalyzing}
      />

      <OfflineIndicator />

      <MarketStrip
        quote={snapshot?.quote ?? null}
        indicators={snapshot?.indicators ?? null}
        balance={activeBalance}
        equity={equity}
        floatingPnl={floatingPnl}
        totalExposurePercent={exposureMetrics.pct}
        mt5Status={mt5Status}
        streamConnected={streamConnected}
      />

      <main className="flex-1 pb-20 md:pb-0">
        {activeTab === 'terminal' && (
          <div className="p-4 lg:p-5 space-y-4 max-w-[1600px] mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-4 items-stretch">
              <CandlestickChart
                ref={chartRef}
                snapshot={snapshot}
                latestAnalysis={latestAnalysis}
                openPositions={activePositions}
                loading={loadingFeed}
                error={feedError}
                onRetry={connectStream}
              />
              <EaSignalPanel
                analysis={latestAnalysis}
                quote={snapshot?.quote ?? null}
                config={config}
                balance={activeBalance}
                atr14={snapshot?.indicators.atr14 ?? null}
                totalExposurePercent={exposureMetrics.pct}
                totalExposureUsd={exposureMetrics.usd}
                mt5Status={mt5Status}
                isAnalyzing={isAnalyzing}
                analysisError={analysisError}
                autoCountdownSec={autoCountdownSec}
                onToggleAutoAnalyze={() =>
                  setConfig((prev) => ({ ...prev, autoAnalyze: !prev.autoAnalyze }))
                }
                onToggleAutoExecute={() =>
                  setConfig((prev) => ({ ...prev, autoExecute: !prev.autoExecute }))
                }
                onToggleFullAiControl={() =>
                  setConfig((prev) => ({
                    ...prev,
                    fullAiControl: !(prev.fullAiControl ?? true),
                  }))
                }
                onAnalyzeNow={() => void runGeminiAnalysis(false)}
                onExecuteAiSignal={handleExecuteAiSignal}
                onQuickMarketOrder={handleQuickMarketOrder}
              />
            </div>

            <PositionsDrawer
              openPositions={activePositions}
              closedTrades={closedTrades}
              analysisLogs={analysisLogs}
              quote={snapshot?.quote ?? null}
              onClosePosition={(id) => void handleClosePosition(id)}
              onCloseAll={() => void handleCloseAll()}
            />
          </div>
        )}

        {activeTab === 'analytics' && (
          <HistoryAnalyticsView
            closedTrades={closedTrades}
            initialBalance={config.initialBalance}
            currentBalance={activeBalance}
          />
        )}

        {activeTab === 'settings' && (
          <EaSettingsView
            config={config}
            onUpdateConfig={(patch) => setConfig((prev) => ({ ...prev, ...patch }))}
            onResetAccount={handleResetAccount}
          />
        )}

        {activeTab === 'bridge' && (
          <Mql5BridgeView
            mt5Status={mt5Status}
            strategyFocus={config.strategyFocus}
            fullAiControl={config.fullAiControl ?? true}
            onRefreshStatus={refreshMt5Status}
          />
        )}
      </main>

      <RiskToastStack
        notifications={riskNotifications}
        onDismiss={(id) =>
          setRiskNotifications((prev) => prev.filter((item) => item.id !== id))
        }
      />

      {/* Sticky Android / Mobile Bottom Navigation Bar */}
      <nav
        aria-label="Navigasi seluler"
        className="md:hidden fixed bottom-0 inset-x-0 z-40 border-t border-white/[0.1] bg-[#0B0E14]/95 backdrop-blur-md pb-[env(safe-area-inset-bottom)]"
      >
        <div className="grid grid-cols-4 h-14">
          {(
            [
              { id: 'terminal', label: 'Terminal', Icon: CandlestickIcon },
              { id: 'analytics', label: 'Performa', Icon: BarChart3 },
              { id: 'settings', label: 'Parameter', Icon: SlidersHorizontal },
              { id: 'bridge', label: 'MT5', Icon: Cpu },
            ] as const
          ).map(({ id, label, Icon }) => {
            const isActive = activeTab === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setActiveTab(id)}
                className={`flex flex-col items-center justify-center gap-1 text-[11px] font-medium transition-colors ${
                  isActive ? 'text-[#D4AF37]' : 'text-[#94A3B8] active:text-[#F8FAFC]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
