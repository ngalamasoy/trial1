import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import crypto from 'crypto';
import type {
  Candle,
  EaAnalysisResult,
  MarketQuote,
  MarketSnapshot,
  Mt5AccountConfig,
  Mt5BridgeStatus,
  Mt5LivePosition,
} from './src/types/trading.ts';
import { buildIndicatorPack } from './src/utils/indicators.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);

// Shared Gemini client (server-side only)
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error(
      'GEMINI_API_KEY belum terkonfigurasi. Pastikan API key tersedia di Settings > Secrets.'
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// ---------- Live XAU/USD M5 Market Data Engine ----------

interface RawFeedResult {
  candles: Candle[];
  bid: number;
  ask: number;
  mid: number;
  high24h: number;
  low24h: number;
  change24h: number;
  changePercent24h: number;
  source: string;
  marketStatus: 'LIVE' | 'DELAYED';
}

let cachedSnapshot: MarketSnapshot | null = null;
let lastFetchAt = 0;
let activeFetchPromise: Promise<MarketSnapshot> | null = null;

function alignToM5(unixSeconds: number): number {
  return Math.floor(unixSeconds / 300) * 300;
}

async function fetchYahooXauM5(symbol: 'XAUUSD=X' | 'GC=F'): Promise<RawFeedResult | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(
      symbol
    )}?interval=5m&range=2d`;
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; AurumEA/1.0)',
        Accept: 'application/json',
      },
    });
    if (!res.ok) return null;
    const json = (await res.json()) as {
      chart?: {
        result?: Array<{
          meta?: {
            regularMarketPrice?: number;
            chartPreviousClose?: number;
            previousClose?: number;
            regularMarketDayHigh?: number;
            regularMarketDayLow?: number;
          };
          timestamp?: number[];
          indicators?: {
            quote?: Array<{
              open?: Array<number | null>;
              high?: Array<number | null>;
              low?: Array<number | null>;
              close?: Array<number | null>;
              volume?: Array<number | null>;
            }>;
          };
        }>;
      };
    };

    const result = json.chart?.result?.[0];
    if (!result?.timestamp || !result.indicators?.quote?.[0]) return null;

    const ts = result.timestamp;
    const q = result.indicators.quote[0];
    const candles: Candle[] = [];

    for (let i = 0; i < ts.length; i++) {
      const o = q.open?.[i];
      const h = q.high?.[i];
      const l = q.low?.[i];
      const c = q.close?.[i];
      const v = q.volume?.[i] ?? 0;
      if (o == null || h == null || l == null || c == null) continue;
      candles.push({
        time: alignToM5(ts[i]),
        open: Number(o.toFixed(2)),
        high: Number(h.toFixed(2)),
        low: Number(l.toFixed(2)),
        close: Number(c.toFixed(2)),
        volume: Number(v || 100),
      });
    }

    if (candles.length < 30) return null;

    // Deduplicate sorted by time
    const dedup = new Map<number, Candle>();
    for (const c of candles) dedup.set(c.time, c);
    const sorted = Array.from(dedup.values()).sort((a, b) => a.time - b.time);

    const last = sorted[sorted.length - 1];
    const metaPrice = result.meta?.regularMarketPrice;
    const mid = Number((metaPrice && metaPrice > 500 ? metaPrice : last.close).toFixed(2));
    last.close = mid;
    if (mid > last.high) last.high = mid;
    if (mid < last.low) last.low = mid;

    const halfSpread = 0.14; // Typical ECN XAU/USD spread (~28 cents)
    const bid = Number((mid - halfSpread).toFixed(2));
    const ask = Number((mid + halfSpread).toFixed(2));

    const prevClose =
      result.meta?.chartPreviousClose ??
      result.meta?.previousClose ??
      sorted[Math.max(0, sorted.length - 288)].open;
    const change24h = Number((mid - prevClose).toFixed(2));
    const changePercent24h = prevClose > 0 ? Number(((change24h / prevClose) * 100).toFixed(2)) : 0;

    const recent24h = sorted.slice(-288);
    const high24h = Number(
      Math.max(result.meta?.regularMarketDayHigh ?? 0, ...recent24h.map((c) => c.high)).toFixed(2)
    );
    const low24h = Number(
      Math.min(
        result.meta?.regularMarketDayLow ?? 999999,
        ...recent24h.map((c) => c.low)
      ).toFixed(2)
    );

    const ageSec = Math.floor(Date.now() / 1000) - last.time;
    const isFresh = ageSec < 900; // < 15 minutes

    return {
      candles: sorted.slice(-220),
      bid,
      ask,
      mid,
      high24h,
      low24h,
      change24h,
      changePercent24h,
      source: symbol === 'XAUUSD=X' ? 'Spot XAU/USD (Yahoo Feed)' : 'COMEX Gold GC=F',
      marketStatus: isFresh ? 'LIVE' : 'DELAYED',
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchBinancePaxgM5(): Promise<RawFeedResult | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  try {
    const [klineRes, tickerRes] = await Promise.all([
      fetch(
        'https://data-api.binance.vision/api/v3/klines?symbol=PAXGUSDT&interval=5m&limit=240',
        { signal: controller.signal }
      ),
      fetch('https://data-api.binance.vision/api/v3/ticker/24hr?symbol=PAXGUSDT', {
        signal: controller.signal,
      }),
    ]);
    if (!klineRes.ok) return null;

    const rawKlines = (await klineRes.json()) as Array<
      [number, string, string, string, string, string, ...unknown[]]
    >;
    if (!Array.isArray(rawKlines) || rawKlines.length < 30) return null;

    const candles: Candle[] = rawKlines.map((k) => ({
      time: alignToM5(Math.floor(k[0] / 1000)),
      open: Number(Number(k[1]).toFixed(2)),
      high: Number(Number(k[2]).toFixed(2)),
      low: Number(Number(k[3]).toFixed(2)),
      close: Number(Number(k[4]).toFixed(2)),
      volume: Number(Number(k[5]).toFixed(2)),
    }));

    const last = candles[candles.length - 1];
    let bid = Number((last.close - 0.15).toFixed(2));
    let ask = Number((last.close + 0.15).toFixed(2));
    let mid = last.close;
    let high24h = Math.max(...candles.map((c) => c.high));
    let low24h = Math.min(...candles.map((c) => c.low));
    let change24h = 0;
    let changePercent24h = 0;

    if (tickerRes.ok) {
      const t = (await tickerRes.json()) as {
        bidPrice?: string;
        askPrice?: string;
        lastPrice?: string;
        highPrice?: string;
        lowPrice?: string;
        priceChange?: string;
        priceChangePercent?: string;
      };
      const b = Number(t.bidPrice);
      const a = Number(t.askPrice);
      const lp = Number(t.lastPrice);
      if (b > 0 && a > 0) {
        bid = Number(b.toFixed(2));
        ask = Number(a.toFixed(2));
        mid = Number(((b + a) / 2).toFixed(2));
      } else if (lp > 0) {
        mid = Number(lp.toFixed(2));
        bid = Number((mid - 0.15).toFixed(2));
        ask = Number((mid + 0.15).toFixed(2));
      }
      if (Number(t.highPrice) > 0) high24h = Number(Number(t.highPrice).toFixed(2));
      if (Number(t.lowPrice) > 0) low24h = Number(Number(t.lowPrice).toFixed(2));
      if (t.priceChange !== undefined) change24h = Number(Number(t.priceChange).toFixed(2));
      if (t.priceChangePercent !== undefined)
        changePercent24h = Number(Number(t.priceChangePercent).toFixed(2));
    }

    last.close = mid;
    if (mid > last.high) last.high = mid;
    if (mid < last.low) last.low = mid;

    return {
      candles: candles.slice(-220),
      bid,
      ask,
      mid,
      high24h,
      low24h,
      change24h,
      changePercent24h,
      source: 'PAXG/USD 24/7 Spot Gold',
      marketStatus: 'LIVE',
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchKrakenPaxgM5(): Promise<RawFeedResult | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  try {
    const res = await fetch('https://api.kraken.com/0/public/OHLC?pair=PAXGUSD&interval=5', {
      signal: controller.signal,
    });
    if (!res.ok) return null;
    const json = (await res.json()) as {
      result?: Record<string, Array<[number, string, string, string, string, string, string, number]>>;
    };
    const key = Object.keys(json.result || {}).find((k) => k !== 'last');
    if (!key || !json.result?.[key]) return null;
    const rows = json.result[key];
    if (rows.length < 30) return null;

    const candles: Candle[] = rows.slice(-220).map((r) => ({
      time: alignToM5(r[0]),
      open: Number(Number(r[1]).toFixed(2)),
      high: Number(Number(r[2]).toFixed(2)),
      low: Number(Number(r[3]).toFixed(2)),
      close: Number(Number(r[4]).toFixed(2)),
      volume: Number(Number(r[6]).toFixed(2)),
    }));

    const last = candles[candles.length - 1];
    const first = candles[0];
    const mid = last.close;
    const change24h = Number((mid - first.open).toFixed(2));
    const changePercent24h =
      first.open > 0 ? Number(((change24h / first.open) * 100).toFixed(2)) : 0;

    return {
      candles,
      bid: Number((mid - 0.16).toFixed(2)),
      ask: Number((mid + 0.16).toFixed(2)),
      mid,
      high24h: Number(Math.max(...candles.map((c) => c.high)).toFixed(2)),
      low24h: Number(Math.min(...candles.map((c) => c.low)).toFixed(2)),
      change24h,
      changePercent24h,
      source: 'Kraken PAXG/USD Gold',
      marketStatus: 'LIVE',
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function loadBestMarketFeed(): Promise<MarketSnapshot> {
  // Try Forex Spot XAU/USD first; if Forex market is closed (e.g., weekend), prefer 24/7 Gold PAXG/USD
  const spotXau = await fetchYahooXauM5('XAUUSD=X');
  let chosen: RawFeedResult | null = null;

  if (spotXau && spotXau.marketStatus === 'LIVE') {
    chosen = spotXau;
  } else {
    const paxg = await fetchBinancePaxgM5();
    if (paxg) {
      chosen = paxg;
    } else {
      const kraken = await fetchKrakenPaxgM5();
      if (kraken) {
        chosen = kraken;
      } else {
        chosen = spotXau || (await fetchYahooXauM5('GC=F'));
      }
    }
  }

  if (!chosen) {
    throw new Error(
      'Gagal mengambil data pasar XAU/USD real-time dari penyedia feed upstream.'
    );
  }

  const nowSec = Math.floor(Date.now() / 1000);
  const currentBoundary = alignToM5(nowSec);
  const candleCloseInSec = Math.max(0, currentBoundary + 300 - nowSec);

  const pack = buildIndicatorPack(chosen.candles);
  const quote: MarketQuote = {
    symbol: 'XAU/USD',
    timeframe: 'M5',
    bid: chosen.bid,
    ask: chosen.ask,
    mid: chosen.mid,
    spread: Number((chosen.ask - chosen.bid).toFixed(2)),
    change24h: chosen.change24h,
    changePercent24h: chosen.changePercent24h,
    high24h: chosen.high24h,
    low24h: chosen.low24h,
    source: chosen.source,
    marketStatus: chosen.marketStatus,
    updatedAt: Date.now(),
    candleCloseInSec,
  };

  const snapshot: MarketSnapshot = {
    quote,
    candles: chosen.candles,
    indicators: pack.snapshot,
    ema9Series: pack.ema9Series,
    ema21Series: pack.ema21Series,
    ema50Series: pack.ema50Series,
    bbUpperSeries: pack.bbUpperSeries,
    bbLowerSeries: pack.bbLowerSeries,
  };

  cachedSnapshot = snapshot;
  lastFetchAt = Date.now();
  return snapshot;
}

async function getMarketSnapshot(forceRefresh = false): Promise<MarketSnapshot> {
  const ageMs = Date.now() - lastFetchAt;
  if (!forceRefresh && cachedSnapshot && ageMs < 2000) {
    // Refresh countdown without hitting upstream every millisecond
    const nowSec = Math.floor(Date.now() / 1000);
    const currentBoundary = alignToM5(nowSec);
    cachedSnapshot.quote.candleCloseInSec = Math.max(0, currentBoundary + 300 - nowSec);
    return cachedSnapshot;
  }

  if (activeFetchPromise) {
    return activeFetchPromise;
  }

  activeFetchPromise = loadBestMarketFeed().finally(() => {
    activeFetchPromise = null;
  });
  return activeFetchPromise;
}

// ---------- Express App Setup ----------

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '6mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      hasGeminiKey: Boolean(
        process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'
      ),
      timestamp: Date.now(),
    });
  });

  // ---------- MetaTrader 5 Real Account & Order Bridge State ----------
  interface Mt5Command {
    id: string;
    action: 'BUY' | 'SELL' | 'CLOSE' | 'CLOSE_ALL';
    lots?: number;
    sl?: number;
    tp?: number;
    ticket?: number;
    comment?: string;
    createdAt: number;
  }

  let mt5Profile: Mt5AccountConfig | null = null;
  let mt5LastHeartbeatAt: number | null = null;
  let mt5LiveAccount: Mt5BridgeStatus['liveAccount'] = null;
  let mt5CommandQueue: Mt5Command[] = [];

  function buildMt5StatusPayload(): Mt5BridgeStatus {
    const isConnected =
      mt5Profile !== null &&
      mt5LastHeartbeatAt !== null &&
      Date.now() - mt5LastHeartbeatAt < 15000;

    return {
      configured: mt5Profile !== null,
      connected: isConnected,
      profile: mt5Profile,
      lastHeartbeatAt: mt5LastHeartbeatAt,
      liveAccount: mt5LiveAccount,
      pendingCommandsCount: mt5CommandQueue.length,
    };
  }

  app.post('/api/mt5/account/connect', (req, res) => {
    const body = req.body as {
      login?: string;
      password?: string;
      server?: string;
      accountType?: 'REAL' | 'DEMO';
    };

    const login = String(body.login || '').trim();
    const password = String(body.password || '');
    const server = String(body.server || '').trim();
    const accountType = body.accountType === 'DEMO' ? 'DEMO' : 'REAL';

    if (!login || !/^\d{3,15}$/.test(login)) {
      res.status(400).json({ error: 'Nomor Login MT5 harus berupa angka 3-15 digit.' });
      return;
    }
    if (!server || server.length < 3) {
      res.status(400).json({ error: 'Nama Server Broker MT5 wajib diisi (contoh: Exness-MT5Real12).' });
      return;
    }
    if (!password || password.length < 3) {
      res.status(400).json({ error: 'Password trading akun MT5 wajib diisi.' });
      return;
    }

    // Derive deterministic bridgeKey without ever storing or echoing the plaintext password
    const secretSalt = process.env.GEMINI_API_KEY || 'aurumea-mt5-bridge';
    const digest = crypto
      .createHmac('sha256', secretSalt)
      .update(`${login}|${server}|${password}`)
      .digest('hex')
      .slice(0, 24);

    mt5Profile = {
      login,
      server,
      accountType,
      bridgeKey: `aurum_${digest}`,
      configuredAt: Date.now(),
    };
    mt5LastHeartbeatAt = null;
    mt5LiveAccount = null;
    mt5CommandQueue = [];

    res.json(buildMt5StatusPayload());
  });

  app.post('/api/mt5/account/disconnect', (_req, res) => {
    mt5Profile = null;
    mt5LastHeartbeatAt = null;
    mt5LiveAccount = null;
    mt5CommandQueue = [];
    res.json(buildMt5StatusPayload());
  });

  app.get('/api/mt5/status', (_req, res) => {
    res.json(buildMt5StatusPayload());
  });

  app.post('/api/mt5/order', (req, res) => {
    const status = buildMt5StatusPayload();
    if (!status.connected || !mt5Profile) {
      res.status(409).json({
        error:
          'Terminal MT5 belum mengirim heartbeat aktif. Pastikan EA AurumEA_XAUUSD_M5 berjalan di MetaTrader 5 Anda.',
      });
      return;
    }

    const body = req.body as {
      action?: 'BUY' | 'SELL' | 'CLOSE' | 'CLOSE_ALL';
      lots?: number;
      sl?: number;
      tp?: number;
      ticket?: number;
      comment?: string;
    };

    const action = body.action;
    if (action !== 'BUY' && action !== 'SELL' && action !== 'CLOSE' && action !== 'CLOSE_ALL') {
      res.status(400).json({ error: 'Tipe perintah order MT5 tidak valid.' });
      return;
    }

    const cmd: Mt5Command = {
      id: `cmd_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      action,
      lots: body.lots,
      sl: body.sl,
      tp: body.tp,
      ticket: body.ticket,
      comment: (body.comment || 'AurumEA Web').replace(/\|/g, '/').slice(0, 40),
      createdAt: Date.now(),
    };
    mt5CommandQueue.push(cmd);

    res.json({ queued: true, command: cmd, pendingCommandsCount: mt5CommandQueue.length });
  });

  // Heartbeat & live account/position sync from MT5 EA / DLL
  app.post('/api/mt5/sync', (req, res) => {
    const body = req.body as {
      bridgeKey?: string;
      login?: string;
      server?: string;
      company?: string;
      currency?: string;
      balance?: number;
      equity?: number;
      margin?: number;
      freeMargin?: number;
      leverage?: number;
      tradeAllowed?: boolean;
      positions?: Mt5LivePosition[];
    };

    if (!mt5Profile) {
      res.status(404).json({
        error: 'Belum ada akun MT5 yang didaftarkan di web terminal.',
        mt5Line: 'NONE',
      });
      return;
    }

    const keyMatch = body.bridgeKey && body.bridgeKey === mt5Profile.bridgeKey;
    const loginServerMatch =
      String(body.login || '').trim() === mt5Profile.login &&
      String(body.server || '').trim().toLowerCase() === mt5Profile.server.toLowerCase();

    if (!keyMatch && !loginServerMatch) {
      res.status(401).json({
        error: `Kredensial Bridge tidak cocok dengan akun terdaftar (${mt5Profile.login} @ ${mt5Profile.server}).`,
        mt5Line: 'NONE',
      });
      return;
    }

    mt5LastHeartbeatAt = Date.now();
    mt5LiveAccount = {
      login: String(body.login || mt5Profile.login),
      server: String(body.server || mt5Profile.server),
      company: String(body.company || 'MetaTrader 5 Broker'),
      currency: String(body.currency || 'USD'),
      balance: Number(body.balance ?? 0),
      equity: Number(body.equity ?? 0),
      margin: Number(body.margin ?? 0),
      freeMargin: Number(body.freeMargin ?? 0),
      leverage: Number(body.leverage ?? 100),
      tradeAllowed: Boolean(body.tradeAllowed ?? true),
      positions: Array.isArray(body.positions) ? body.positions : [],
    };

    const nextCmd = mt5CommandQueue.shift();
    let mt5Line = 'NONE';
    if (nextCmd) {
      if (nextCmd.action === 'BUY' || nextCmd.action === 'SELL') {
        mt5Line = [
          'CMD',
          nextCmd.id,
          nextCmd.action,
          Number(nextCmd.lots || 0.01).toFixed(2),
          Number(nextCmd.sl || 0).toFixed(2),
          Number(nextCmd.tp || 0).toFixed(2),
          nextCmd.comment || 'AurumEA',
        ].join('|');
      } else if (nextCmd.action === 'CLOSE') {
        mt5Line = ['CMD', nextCmd.id, 'CLOSE', String(nextCmd.ticket || 0)].join('|');
      } else if (nextCmd.action === 'CLOSE_ALL') {
        mt5Line = ['CMD', nextCmd.id, 'CLOSE_ALL'].join('|');
      }
    }

    res.json({ ok: true, mt5Line });
  });

  app.get('/api/market/candles', async (_req, res) => {
    try {
      const snapshot = await getMarketSnapshot(false);
      res.json(snapshot);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Gagal memuat data chart XAU/USD.';
      res.status(502).json({ error: message });
    }
  });

  // Real-time Server-Sent Events stream for XAU/USD M5 ticks
  app.get('/api/market/stream', async (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    let closed = false;

    const pushTick = async (force: boolean) => {
      if (closed) return;
      try {
        const snapshot = await getMarketSnapshot(force);
        if (!closed) {
          res.write(`event: tick\ndata: ${JSON.stringify(snapshot)}\n\n`);
        }
      } catch (err) {
        if (!closed) {
          const message = err instanceof Error ? err.message : 'Feed error';
          res.write(`event: feed_error\ndata: ${JSON.stringify({ error: message })}\n\n`);
        }
      }
    };

    await pushTick(false);

    const interval = setInterval(() => {
      void pushTick(true);
    }, 3000);

    req.on('close', () => {
      closed = true;
      clearInterval(interval);
    });
  });

  // Real-time Gemini AI Expert Advisor analysis endpoint
  app.post('/api/ea/analyze', async (req, res) => {
    const startTime = Date.now();
    try {
      const body = req.body as {
        chartImageBase64?: string;
        strategyFocus?: 'BALANCED' | 'SCALPING_EMA' | 'ULTRA_SCALP' | 'LIQUIDITY_SMC';
        riskPercent?: number;
        accountBalance?: number;
        openPositionsCount?: number;
        openPositionsSummary?: string;
        mt5Symbol?: string;
        mt5Bid?: number;
        mt5Ask?: number;
        mt5SpreadPoints?: number;
        fullAiControl?: boolean;
        mt5Candles?: Candle[];
        mt5M1Candles?: Candle[];
      };

      let snapshot: MarketSnapshot;
      if (Array.isArray(body.mt5Candles) && body.mt5Candles.length >= 30) {
        const cleanedCandles = body.mt5Candles
          .filter(
            (c) =>
              typeof c.time === 'number' &&
              typeof c.open === 'number' &&
              typeof c.high === 'number' &&
              typeof c.low === 'number' &&
              typeof c.close === 'number'
          )
          .sort((a, b) => a.time - b.time);

        const last = cleanedCandles[cleanedCandles.length - 1];
        const bid = Number((body.mt5Bid && body.mt5Bid > 0 ? body.mt5Bid : last.close).toFixed(2));
        const ask = Number(
          (body.mt5Ask && body.mt5Ask > 0 ? body.mt5Ask : bid + 0.25).toFixed(2)
        );
        const mid = Number(((bid + ask) / 2).toFixed(2));
        const pack = buildIndicatorPack(cleanedCandles);
        const nowSec = Math.floor(Date.now() / 1000);
        const boundary = alignToM5(nowSec);
        const firstOpen = cleanedCandles[0].open;
        const change24h = Number((mid - firstOpen).toFixed(2));

        snapshot = {
          quote: {
            symbol: body.mt5Symbol || 'XAUUSD (MT5)',
            timeframe: 'M5',
            bid,
            ask,
            mid,
            spread: Number((ask - bid).toFixed(2)),
            change24h,
            changePercent24h:
              firstOpen > 0 ? Number(((change24h / firstOpen) * 100).toFixed(2)) : 0,
            high24h: Number(Math.max(...cleanedCandles.map((c) => c.high)).toFixed(2)),
            low24h: Number(Math.min(...cleanedCandles.map((c) => c.low)).toFixed(2)),
            source: `MetaTrader 5 (${body.mt5Symbol || 'XAUUSD'})`,
            marketStatus: 'LIVE',
            updatedAt: Date.now(),
            candleCloseInSec: Math.max(0, boundary + 300 - nowSec),
          },
          candles: cleanedCandles,
          indicators: pack.snapshot,
          ema9Series: pack.ema9Series,
          ema21Series: pack.ema21Series,
          ema50Series: pack.ema50Series,
          bbUpperSeries: pack.bbUpperSeries,
          bbLowerSeries: pack.bbLowerSeries,
        };
      } else {
        snapshot = await getMarketSnapshot(true);
      }

      const recentCandles = snapshot.candles.slice(-30);
      const lastCandle = recentCandles[recentCandles.length - 1];
      const ind = snapshot.indicators;

      const candleTable = recentCandles
        .map((c) => {
          const iso = new Date(c.time * 1000).toISOString().slice(11, 16);
          const dir = c.close >= c.open ? 'BULL' : 'BEAR';
          const bodySz = Math.abs(c.close - c.open).toFixed(2);
          const upWick = (c.high - Math.max(c.open, c.close)).toFixed(2);
          const dnWick = (Math.min(c.open, c.close) - c.low).toFixed(2);
          return `${iso} | O:${c.open} H:${c.high} L:${c.low} C:${c.close} | Body:${bodySz} UW:${upWick} LW:${dnWick} (${dir})`;
        })
        .join('\n');

      // Optional M1 micro-structure table sent by MT5 Scalping EA v2.00
      let m1Section = '';
      if (Array.isArray(body.mt5M1Candles) && body.mt5M1Candles.length >= 5) {
        const m1Clean = body.mt5M1Candles
          .filter(
            (c) =>
              typeof c.time === 'number' &&
              typeof c.open === 'number' &&
              typeof c.high === 'number' &&
              typeof c.low === 'number' &&
              typeof c.close === 'number'
          )
          .sort((a, b) => a.time - b.time)
          .slice(-15);

        const m1Lines = m1Clean
          .map((c) => {
            const iso = new Date(c.time * 1000).toISOString().slice(11, 16);
            const dir = c.close >= c.open ? 'BULL' : 'BEAR';
            return `${iso} | O:${c.open} H:${c.high} L:${c.low} C:${c.close} (${dir})`;
          })
          .join('\n');
        m1Section = `\n15 CANDLE M1 TERAKHIR (MICRO TIMING SCALPING):\n${m1Lines}\n`;
      }

      // Compute EMA 9/21 slope & gap for scalping momentum context
      const ema9Last = snapshot.ema9Series[snapshot.ema9Series.length - 1]?.value ?? null;
      const ema9Prev = snapshot.ema9Series[snapshot.ema9Series.length - 4]?.value ?? null;
      const ema9Slope =
        ema9Last !== null && ema9Prev !== null ? Number((ema9Last - ema9Prev).toFixed(2)) : null;
      const emaGap =
        ind.ema9 !== null && ind.ema21 !== null ? Number((ind.ema9 - ind.ema21).toFixed(2)) : null;

      const strategyInstructionMap: Record<string, string> = {
        BALANCED:
          'Gunakan konfluensi seimbang: tren EMA 9/21/50, momentum RSI & MACD, serta level Support/Resistance atau ATR.',
        SCALPING_EMA:
          'FOKUS SCALPING M5: Cari momentum searah EMA 9 > EMA 21 > EMA 50 (untuk BUY) atau EMA 9 < EMA 21 < EMA 50 (untuk SELL), pullback ke EMA 9/21 dengan wick rejection atau momentum breakout candle kuat. Gunakan SL ketat (~0.9x - 1.2x ATR) dan TP1 cepat (~1.2x - 1.6x ATR) untuk hit dalam 5-20 menit.',
        ULTRA_SCALP:
          'FOKUS ULTRA-SCALPING (M1 + M5 SNIPER): Prioritaskan micro-momentum tercepat dari urutan candle M1 & M5, sweep likuiditas mikro / wick rejection tajam, dan akselerasi EMA 9. Target TP1 sangat cepat (0.9x - 1.3x ATR, ~1.20-2.50 USD) dengan SL ketat (0.8x - 1.0x ATR). Wajib HOLD jika spread lebar atau market flat tanpa dorongan volume/body candle.',
        LIQUIDITY_SMC:
          'Fokus pada Smart Money Concepts / Price Action Scalping M5: deteksi sweep Swing High/Low, Break of Structure (BOS), wick rejection kuat di zona likuiditas dengan target cepat ke imbalance terdekat.',
      };

      const strategyFocus = body.strategyFocus || 'SCALPING_EMA';
      const isScalpMode = strategyFocus === 'SCALPING_EMA' || strategyFocus === 'ULTRA_SCALP';
      const fullAiControl = body.fullAiControl ?? true;
      const atrValue = ind.atr14 ?? 2.5;
      const spreadInfo =
        typeof body.mt5SpreadPoints === 'number'
          ? `${snapshot.quote.spread} USD (${body.mt5SpreadPoints} pts MT5)`
          : `${snapshot.quote.spread} USD`;
      const slGuide = isScalpMode
        ? `${(atrValue * 0.95).toFixed(2)} - ${(atrValue * 1.15).toFixed(2)}`
        : `${(atrValue * 1.3).toFixed(2)} - ${(atrValue * 1.7).toFixed(2)}`;
      const tpGuide = isScalpMode
        ? `${(atrValue * 1.25).toFixed(2)} - ${(atrValue * 1.6).toFixed(2)}`
        : `${(atrValue * 1.8).toFixed(2)} - ${(atrValue * 2.5).toFixed(2)}`;

      const promptText = `Anda adalah HAKIM KEPUTUSAN TUNGGAL (100% AI Sovereign Judge) untuk eksekusi trading XAU/USD.
ATURAN MUTLAK: Seluruh indikator teknikal di bawah ini HANYA DATA MENTAH PASIF (raw telemetry) — bukan aturan otomatis. Anda sendiri yang menimbang seluruh data, mengabaikan sinyal indikator yang menipu/false, dan memegang 100% kendali penuh untuk memutuskan VONIS AKHIR: "HOLD", "BUY", atau "SELL".

DATA HARGA PASAR REAL-TIME (TELEMETRI):
- Pair: XAU/USD (Timeframe Utama: M5${m1Section ? ' + M1 Micro' : ''})
- Sumber Feed: ${snapshot.quote.source}
- Bid: ${snapshot.quote.bid} | Ask: ${snapshot.quote.ask} | Mid: ${snapshot.quote.mid} | Spread: ${spreadInfo}
- High 24h: ${snapshot.quote.high24h} | Low 24h: ${snapshot.quote.low24h}
- Sisa waktu penutupan candle M5 aktif: ${snapshot.quote.candleCloseInSec} detik

DATA MENTAH INDIKATOR TEKNIKAL (BAHAN PERTIMBANGAN SAJA):
- EMA 9: ${ind.ema9 ?? 'N/A'} (Slope 3-bar: ${ema9Slope !== null ? `${ema9Slope >= 0 ? '+' : ''}${ema9Slope}` : 'N/A'})
- EMA 21: ${ind.ema21 ?? 'N/A'} (Gap EMA9-EMA21: ${emaGap !== null ? `${emaGap >= 0 ? '+' : ''}${emaGap}` : 'N/A'})
- EMA 50: ${ind.ema50 ?? 'N/A'} | EMA 200: ${ind.ema200 ?? 'N/A'}
- RSI (14): ${ind.rsi14 ?? 'N/A'}
- MACD (12,26,9): Line=${ind.macd.line ?? 'N/A'}, Signal=${ind.macd.signal ?? 'N/A'}, Hist=${ind.macd.histogram ?? 'N/A'}
- ATR (14): ${atrValue} USD (Referensi jarak SL scalping: $${slGuide}, TP1 cepat: $${tpGuide})
- Bollinger Bands (20,2): Upper=${ind.bollinger.upper ?? 'N/A'}, Mid=${ind.bollinger.middle ?? 'N/A'}, Lower=${ind.bollinger.lower ?? 'N/A'}
- Swing High (30 candle): ${ind.swingHigh} | Swing Low (30 candle): ${ind.swingLow}

KONTEKS AKUN & GAYA EKSEKUSI:
- Lensa Strategi Pilihan Trader: ${strategyFocus} (${strategyInstructionMap[strategyFocus] || strategyInstructionMap.SCALPING_EMA})
- Mode Otoritas: ${fullAiControl ? '100% KENDALI PENUH AI JUDGE (Vonis Anda langsung menjadi keputusan final eksekusi tanpa filter lokal)' : 'AI Judge + Filter Confidence'}
- Saldo Akun: $${body.accountBalance ?? 10000} | Risk/Trade: ${body.riskPercent ?? 1}%
- Posisi Terbuka Saat Ini: ${body.openPositionsCount ?? 0} (${body.openPositionsSummary || 'Tidak ada posisi aktif'})

30 CANDLE M5 TERAKHIR (UTC — Body=ukuran body, UW=ekor atas, LW=ekor bawah):
${candleTable}
${m1Section}
TUGAS HAKIM KEPUTUSAN AI:
1. Timbang seluruh bukti: gambar chart visual (jika ada), urutan price action candle M5/M1, likuiditas & anatomi wick, spread, dan data mentah indikator.
2. Jika indikator saling bertentangan (misal RSI jenuh tapi price action & struktur breakout kuat, atau sebaliknya EMA terlihat bagus tapi candle choppy/spread lebar), ANDA yang memutuskan mana bukti yang valid dan mana yang jebakan.
3. Keluarkan vonis final yang tegas: "BUY", "SELL", atau "HOLD". Jangan ragu memilih "HOLD" jika probabilitas tidak meyakinkan atau market sideways tanpa arah.
4. Jika vonis "BUY": stopLoss WAJIB di bawah entryPrice dan takeProfit1 & takeProfit2 WAJIB di atas entryPrice.
5. Jika vonis "SELL": stopLoss WAJIB di atas entryPrice dan takeProfit1 & takeProfit2 WAJIB di bawah entryPrice.
6. Jika vonis "HOLD": isi entryPrice dengan harga mid saat ini (${snapshot.quote.mid}), serta zona SL/TP breakout referensi yang logis.
7. Jelaskan secara tajam di \`judgeVerdict\` dan \`indicatorWeighting\` bagaimana Anda menimbang data indikator hingga menjatuhkan vonis final dalam Bahasa Indonesia.`;

      const parts: Array<
        { text: string } | { inlineData: { mimeType: string; data: string } }
      > = [];

      let usedChartVision = false;
      if (body.chartImageBase64 && typeof body.chartImageBase64 === 'string') {
        const cleaned = body.chartImageBase64.replace(/^data:image\/\w+;base64,/, '');
        if (cleaned.length > 100) {
          parts.push({
            inlineData: {
              mimeType: 'image/png',
              data: cleaned,
            },
          });
          usedChartVision = true;
        }
      }
      parts.push({ text: promptText });

      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: { parts },
        config: {
          systemInstruction:
            'Anda adalah AI Hakim Keputusan Tunggal (100% Sovereign Trading Decision Judge) untuk XAU/USD. Indikator teknikal (EMA, RSI, MACD, ATR, Bollinger) BUKAN penentu sinyal otomatis—semuanya hanyalah data mentah untuk Anda timbang. Anda memegang 100% otoritas absolut memutuskan BUY, SELL, atau HOLD berdasarkan sintesis price action, struktur likuiditas, volatilitas, spread, dan gambar chart real-time.',
          thinkingConfig: {
            thinkingLevel: ThinkingLevel.MEDIUM,
          },
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              signal: {
                type: Type.STRING,
                description: 'Vonis keputusan final AI Judge: BUY, SELL, atau HOLD',
              },
              confidence: {
                type: Type.NUMBER,
                description: 'Skor keyakinan hakim AI 0 sampai 100',
              },
              marketBias: {
                type: Type.STRING,
                description: 'Bias struktur M5: BULLISH, BEARISH, atau RANGING',
              },
              judgeVerdict: {
                type: Type.STRING,
                description: 'Kalimat vonis tegas AI Judge (contoh: VONIS AI: BUY — Momentum breakout terkonfirmasi di atas EMA9)',
              },
              indicatorWeighting: {
                type: Type.STRING,
                description: 'Penjelasan singkat bagaimana AI Judge menimbang/menyaring data mentah indikator (EMA, RSI, MACD, ATR, spread)',
              },
              entryPrice: {
                type: Type.NUMBER,
                description: 'Harga entry optimal saat ini dalam USD',
              },
              stopLoss: {
                type: Type.NUMBER,
                description: 'Level Stop Loss presisi dalam USD',
              },
              takeProfit1: {
                type: Type.NUMBER,
                description: 'Target Take Profit 1 scalping cepat dalam USD',
              },
              takeProfit2: {
                type: Type.NUMBER,
                description: 'Target Take Profit 2 lanjutan dalam USD',
              },
              riskRewardRatio: {
                type: Type.STRING,
                description: 'Rasio Risk to Reward, contoh: 1:1.4',
              },
              setupPattern: {
                type: Type.STRING,
                description: 'Nama pola atau setup scalping M5/M1 utama (singkat)',
              },
              summary: {
                type: Type.STRING,
                description: 'Analisa ringkas 2-3 kalimat dalam Bahasa Indonesia',
              },
              keyFactors: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '3-4 poin bukti utama yang dipakai AI Judge untuk menjatuhkan vonis',
              },
              invalidatedIf: {
                type: Type.STRING,
                description: 'Kondisi harga yang membatalkan vonis analisa ini',
              },
            },
            required: [
              'signal',
              'confidence',
              'marketBias',
              'judgeVerdict',
              'indicatorWeighting',
              'entryPrice',
              'stopLoss',
              'takeProfit1',
              'takeProfit2',
              'riskRewardRatio',
              'setupPattern',
              'summary',
              'keyFactors',
              'invalidatedIf',
            ],
          },
        },
      });

      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        throw new Error('Gemini API tidak mengembalikan output analisa.');
      }

      const parsed = JSON.parse(rawText) as {
        signal: string;
        confidence: number;
        marketBias: string;
        judgeVerdict: string;
        indicatorWeighting: string;
        entryPrice: number;
        stopLoss: number;
        takeProfit1: number;
        takeProfit2: number;
        riskRewardRatio: string;
        setupPattern: string;
        summary: string;
        keyFactors: string[];
        invalidatedIf: string;
      };

      const normalizedSignal =
        parsed.signal === 'BUY' || parsed.signal === 'SELL' ? parsed.signal : 'HOLD';
      const normalizedBias =
        parsed.marketBias === 'BULLISH' || parsed.marketBias === 'BEARISH'
          ? parsed.marketBias
          : 'RANGING';

      const refPrice =
        normalizedSignal === 'BUY'
          ? snapshot.quote.ask
          : normalizedSignal === 'SELL'
          ? snapshot.quote.bid
          : snapshot.quote.mid;

      // Mathematical sanity check so broker order stops are never inverted
      let entryPrice = Number((parsed.entryPrice || refPrice).toFixed(2));
      if (Math.abs(entryPrice - refPrice) > atrValue * 2.5) {
        entryPrice = refPrice;
      }

      let stopLoss = Number(parsed.stopLoss.toFixed(2));
      let takeProfit1 = Number(parsed.takeProfit1.toFixed(2));
      let takeProfit2 = Number(parsed.takeProfit2.toFixed(2));

      const slMult = isScalpMode ? 1.0 : 1.5;
      const tp1Mult = isScalpMode ? 1.35 : 2.0;
      const tp2Mult = isScalpMode ? 2.2 : 3.2;

      if (normalizedSignal === 'BUY') {
        if (stopLoss >= entryPrice) stopLoss = Number((entryPrice - atrValue * slMult).toFixed(2));
        if (takeProfit1 <= entryPrice) takeProfit1 = Number((entryPrice + atrValue * tp1Mult).toFixed(2));
        if (takeProfit2 <= takeProfit1) takeProfit2 = Number((entryPrice + atrValue * tp2Mult).toFixed(2));
      } else if (normalizedSignal === 'SELL') {
        if (stopLoss <= entryPrice) stopLoss = Number((entryPrice + atrValue * slMult).toFixed(2));
        if (takeProfit1 >= entryPrice) takeProfit1 = Number((entryPrice - atrValue * tp1Mult).toFixed(2));
        if (takeProfit2 >= takeProfit1) takeProfit2 = Number((entryPrice - atrValue * tp2Mult).toFixed(2));
      }

      const analysis: EaAnalysisResult = {
        id: `ea_${Date.now()}`,
        timestamp: Date.now(),
        candleTime: lastCandle.time,
        priceAtAnalysis: snapshot.quote.mid,
        signal: normalizedSignal,
        confidence: Math.max(0, Math.min(100, Math.round(parsed.confidence || 50))),
        marketBias: normalizedBias,
        entryPrice,
        stopLoss,
        takeProfit1,
        takeProfit2,
        riskRewardRatio: parsed.riskRewardRatio || '1:1.4',
        setupPattern: parsed.setupPattern || 'AI Judge Scalping Confluence',
        summary: parsed.summary || 'Analisa selesai.',
        keyFactors: Array.isArray(parsed.keyFactors) ? parsed.keyFactors.slice(0, 4) : [],
        invalidatedIf: parsed.invalidatedIf || 'Break struktur candle M5 berlawanan.',
        model: 'gemini-4-hydrogen',
        latencyMs: Date.now() - startTime,
        usedChartVision,
        judgeVerdict:
          parsed.judgeVerdict ||
          `VONIS AI: ${normalizedSignal} (${Math.round(parsed.confidence || 50)}%)`,
        indicatorWeighting:
          parsed.indicatorWeighting ||
          'Seluruh indikator telah ditimbang sebagai data mentah oleh AI Judge.',
        authorityMode: fullAiControl ? 'AI_JUDGE_100' : 'CONFIDENCE_FILTER',
      };

      const safePattern = analysis.setupPattern.replace(/\|/g, '/').replace(/[\r\n]+/g, ' ');
      const safeSummary = analysis.summary.replace(/\|/g, '/').replace(/[\r\n]+/g, ' ');
      const mt5Line = [
        analysis.signal,
        analysis.confidence,
        analysis.entryPrice.toFixed(2),
        analysis.stopLoss.toFixed(2),
        analysis.takeProfit1.toFixed(2),
        analysis.takeProfit2.toFixed(2),
        safePattern,
        safeSummary,
      ].join('|');

      res.json({ analysis, mt5Line, snapshot });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      let statusCode = 500;
      let userMessage = msg;

      if (msg.includes('API_KEY_INVALID') || msg.includes('400')) {
        statusCode = 400;
        userMessage =
          'GEMINI_API_KEY tidak valid. Silakan periksa API key Anda di panel Settings > Secrets.';
      } else if (msg.includes('PERMISSION_DENIED') || msg.includes('403')) {
        statusCode = 403;
        userMessage =
          'Akses Gemini API ditolak (403). Periksa izin GEMINI_API_KEY Anda di Settings > Secrets.';
      } else if (msg.includes('RESOURCE_EXHAUSTED') || msg.includes('429')) {
        statusCode = 429;
        userMessage =
          'Kuota/rate limit Gemini API tercapai (429). Tunggu beberapa saat atau gunakan interval analisa yang lebih panjang.';
      } else if (msg.includes('NOT_FOUND') || msg.includes('404')) {
        statusCode = 404;
        userMessage = 'Endpoint model Gemini tidak ditemukan (404).';
      }

      res.status(statusCode).json({ error: userMessage });
    }
  });

  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: { server: httpServer },
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(
      express.static(distDir, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('.webmanifest')) {
            res.setHeader('Content-Type', 'application/manifest+json');
          } else if (filePath.endsWith('sw.js')) {
            res.setHeader('Cache-Control', 'no-cache');
          }
        },
      })
    );
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`AurumEA XAU/USD M5 Server listening on http://0.0.0.0:${PORT}`);
  });
}

void startServer();
